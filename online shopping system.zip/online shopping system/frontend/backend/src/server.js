const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const path = require('path');
const mongoose = require('mongoose');

require('dotenv').config();

const User = require('./models/user.model');
const Product = require('./models/product.model');
const Order = require('./models/order.model');
const Cart  = require('./models/cart.model');
const ActivityLog = require('./models/activity.model');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'fallback_secret';
const MONGO_URI = process.env.MONGO_URI;

mongoose.connect(MONGO_URI)
  .then(() => console.log('✅ Connected to MongoDB Atlas successfully!'))
  .catch(err => console.error('❌ MongoDB Connection Error:', err));

app.use(cors({ origin: '*' }));
app.use(express.json());

// Serve frontend folder as static files
app.use(express.static(path.join(__dirname, '..', '..', 'frontend')));

// ─── Auth Middleware ───────────────────────────────────────────────────────
const auth = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'Unauthorized' });
  try { req.user = jwt.verify(token, JWT_SECRET); next(); }
  catch { res.status(401).json({ error: 'Invalid token' }); }
};
const adminOnly = (req, res, next) => {
  if (req.user?.role !== 'admin') return res.status(403).json({ error: 'Admin access only' });
  next();
};

// ─── AUTH ──────────────────────────────────────────────────────────────────
app.post('/api/auth/signup', async (req, res) => {
  try {
    const { name, email, password, phone, address } = req.body;
    if (!name || !email || !password) return res.status(400).json({ error: 'Name, email and password are required' });
    
    const existing = await User.findOne({ email });
    if (existing) return res.status(409).json({ error: 'Email already registered' });
    
    const hashed = await bcrypt.hash(password, 8);
    const user = await User.create({ name, email, password: hashed, phone: phone||'', address: address||'', role: 'customer' });
    
    await ActivityLog.create({ type:'user', message:`New customer ${name} registered`, time:'just now' });
    
    const token = jwt.sign({ id:user.id, name:user.name, email:user.email, role:user.role }, JWT_SECRET, { expiresIn:'7d' });
    res.json({ token, user: { id:user.id, name:user.name, email:user.email, role:user.role } });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user || !await bcrypt.compare(password, user.password)) return res.status(401).json({ error: 'Invalid email or password' });
    
    const token = jwt.sign({ id:user.id, name:user.name, email:user.email, role:user.role }, JWT_SECRET, { expiresIn:'7d' });
    res.json({ token, user: { id:user.id, name:user.name, email:user.email, role:user.role } });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// ─── PRODUCTS ──────────────────────────────────────────────────────────────
app.get('/api/products', async (req, res) => {
  try {
    const { search, category, maxPrice, sort } = req.query;
    let query = {};
    if (search) query.$or = [{ name: new RegExp(search, 'i') }, { description: new RegExp(search, 'i') }];
    if (category && category !== 'All') query.category = category;
    if (maxPrice) query.price = { $lte: Number(maxPrice) };
    
    let sortObj = {};
    if (sort === 'price_asc')  sortObj = { price: 1 };
    else if (sort === 'price_desc') sortObj = { price: -1 };
    else if (sort === 'rating')     sortObj = { rating: -1 };
    else sortObj = { createdAt: -1 };
    
    const products = await Product.find(query).sort(sortObj);
    res.json(products);
  } catch(e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/products/:id', async (req, res) => {
  try {
    const p = await Product.findById(req.params.id);
    if (!p) return res.status(404).json({ error: 'Product not found' });
    res.json(p);
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// ─── CART ──────────────────────────────────────────────────────────────────
app.get('/api/cart', auth, async (req, res) => {
  const cart = await Cart.findOne({ userId: req.user.id });
  res.json(cart ? cart.items : []);
});

app.post('/api/cart/add', auth, async (req, res) => {
  const { productId, qty } = req.body;
  const product = await Product.findById(productId);
  if (!product) return res.status(404).json({ error: 'Product not found' });
  
  let cart = await Cart.findOne({ userId: req.user.id });
  if (!cart) cart = new Cart({ userId: req.user.id, items: [] });
  
  const existing = cart.items.find(i => i.productId === productId);
  if (existing) existing.qty += qty || 1;
  else cart.items.push({ productId, name:product.name, price:product.price, qty:qty||1, image:product.image });
  
  await cart.save();
  res.json(cart.items);
});

app.put('/api/cart/update', auth, async (req, res) => {
  const { productId, qty } = req.body;
  const cart = await Cart.findOne({ userId: req.user.id });
  if (!cart) return res.json([]);
  
  if (qty <= 0) cart.items = cart.items.filter(i => i.productId !== productId);
  else { const item = cart.items.find(i => i.productId === productId); if (item) item.qty = qty; }
  
  await cart.save();
  res.json(cart.items);
});

app.delete('/api/cart/remove/:productId', auth, async (req, res) => {
  const cart = await Cart.findOne({ userId: req.user.id });
  if (cart) {
    cart.items = cart.items.filter(i => i.productId !== req.params.productId);
    await cart.save();
  }
  res.json(cart ? cart.items : []);
});

app.delete('/api/cart/clear', auth, async (req, res) => {
  await Cart.findOneAndUpdate({ userId: req.user.id }, { items: [] }, { upsert: true });
  res.json([]);
});

// ─── ORDERS ────────────────────────────────────────────────────────────────
app.post('/api/orders', auth, async (req, res) => {
  try {
    const { paymentMethod, address } = req.body;
    const cart = await Cart.findOne({ userId: req.user.id });
    if (!cart || !cart.items.length) return res.status(400).json({ error: 'Cart is empty' });
    
    const total = cart.items.reduce((s, i) => s + i.price * i.qty, 0);
    const newOrder = await Order.create({
      id: 'ord' + uuidv4().slice(0,6).toUpperCase(),
      userId: req.user.id, items: cart.items, total,
      status: 'Processing', paymentMethod, paymentStatus: 'Paid',
      address
    });
    
    await Cart.updateOne({ userId: req.user.id }, { items: [] });
    await ActivityLog.create({ type:'order', message:`New order ${newOrder.id} placed by ${req.user.name} – ₹${total.toLocaleString('en-IN')}`, time:'just now' });
    
    res.json(newOrder);
  } catch(e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/orders', auth, async (req, res) => {
  const query = req.user.role === 'admin' ? {} : { userId: req.user.id };
  const orders = await Order.find(query).sort({ date: -1 });
  res.json(orders);
});

app.get('/api/orders/:id', auth, async (req, res) => {
  const order = await Order.findOne({ id: req.params.id });
  if (!order) return res.status(404).json({ error: 'Order not found' });
  if (req.user.role !== 'admin' && order.userId !== req.user.id) return res.status(403).json({ error: 'Forbidden' });
  res.json(order);
});

// ─── ADMIN ─────────────────────────────────────────────────────────────────
app.get('/api/admin/dashboard', auth, adminOnly, async (req, res) => {
  try {
    const totalUsers = await User.countDocuments({ role: 'customer' });
    const totalProducts = await Product.countDocuments();
    const totalOrdersCount = await Order.countDocuments();
    
    const orders = await Order.find();
    const totalRevenue = orders.filter(o => o.paymentStatus === 'Paid').reduce((s, o) => s + o.total, 0);
    
    const recentOrders = await Order.find().sort({ date: -1 }).limit(5);
    const activityLog = await ActivityLog.find().sort({ createdAt: -1 }).limit(8);
    
    res.json({ totalUsers, totalProducts, totalOrders: totalOrdersCount, totalRevenue, recentOrders, activityLog });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/admin/customers', auth, adminOnly, async (req, res) => {
  const users = await User.find({ role: 'customer' });
  const custData = [];
  for (let u of users) {
    const ordersCount = await Order.countDocuments({ userId: u.id });
    custData.push({ id: u.id, name: u.name, email: u.email, phone: u.phone, address: u.address, createdAt: u.createdAt, orders: ordersCount });
  }
  res.json(custData);
});

app.post('/api/admin/products', auth, adminOnly, async (req, res) => {
  try {
    const { name, price, description, stock, category, image } = req.body;
    if (!name || !price) return res.status(400).json({ error: 'Name and price required' });
    const p = await Product.create({ name, price:Number(price), description:description||'', stock:Number(stock)||0, category:category||'Other', rating:4.0, reviews:0, image:image||'' });
    await ActivityLog.create({ type:'product', message:`Product "${name}" added by admin`, time:'just now' });
    res.json(p);
  } catch(e) { res.status(500).json({ error: e.message }); }
});

app.put('/api/admin/products/:id', auth, adminOnly, async (req, res) => {
  try {
    const p = await Product.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!p) return res.status(404).json({ error: 'Not found' });
    res.json(p);
  } catch(e) { res.status(500).json({ error: e.message }); }
});

app.delete('/api/admin/products/:id', auth, adminOnly, async (req, res) => {
  await Product.findByIdAndDelete(req.params.id);
  res.json({ success: true });
});

app.put('/api/admin/orders/:id/status', auth, adminOnly, async (req, res) => {
  try {
    const order = await Order.findOneAndUpdate({ id: req.params.id }, { status: req.body.status }, { new: true });
    if (!order) return res.status(404).json({ error: 'Order not found' });
    await ActivityLog.create({ type:'order', message:`Order ${order.id} status → "${req.body.status}"`, time:'just now' });
    res.json(order);
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// Catch-all: serve frontend
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '..', '..', 'frontend', 'index.html'));
});

app.listen(PORT, () => {
  console.log('\\n╔══════════════════════════════════════════╗');
  console.log('║   🚀 ShopNova Server Started!             ║');
  console.log(`║   🌐 http://localhost:${PORT}               ║`);
  console.log('╠══════════════════════════════════════════╣');
  console.log('║  👤 Customer: alice@email.com / password123║');
  console.log('║  🔑 Admin:    admin@shopnova.com / admin123 ║');
  console.log('╚══════════════════════════════════════════╝\\n');
});
