const mongoose = require('mongoose');

const activitySchema = new mongoose.Schema({
  type: { type: String, enum: ['user', 'order', 'product', 'payment'], required: true },
  message: { type: String, required: true },
  time: { type: String, required: true }, // Keeping strings like 'just now' to match ui specs for simplicity, or we can use diff logic
  createdAt: { type: Date, default: Date.now }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

module.exports = mongoose.model('ActivityLog', activitySchema);
