const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  name: { type: String, required: true },
  price: { type: Number, required: true },
  description: { type: String, default: '' },
  stock: { type: Number, default: 0 },
  category: { type: String, default: 'Other' },
  rating: { type: Number, default: 4.0 },
  reviews: { type: Number, default: 0 },
  image: { type: String, default: '' }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

module.exports = mongoose.model('Product', productSchema);
