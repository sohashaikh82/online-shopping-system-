const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const { faker } = require('@faker-js/faker');
require('dotenv').config({ path: require('path').resolve(__dirname, '../.env') });

const User = require('./models/user.model');
const Product = require('./models/product.model');
const ActivityLog = require('./models/activity.model');

async function seed() {
  console.log('Starting dynamic seed process for new cluster...');
  if (!process.env.MONGO_URI) { console.error('MONGO_URI is missing from .env!'); process.exit(1); }
  
  await mongoose.connect(process.env.MONGO_URI);
  console.log('✅ Connected to MongoDB successfully');

  console.log('Clearing existing data...');
  await User.deleteMany({});
  await Product.deleteMany({});
  await ActivityLog.deleteMany({});

  console.log('Seeding core system accounts...');
  const hashedAdmin = await bcrypt.hash('admin123', 8);
  await User.create({ name: 'Soha Admin', email: 'admin@shopnova.com', password: hashedAdmin, role: 'admin', phone:'1234567890', address: 'Main Hub' });
  
  const hashedCustomer = await bcrypt.hash('password123', 8);
  await User.create({ name: 'Alice Customer', email: 'alice@email.com', password: hashedCustomer, role: 'customer', phone:'9000010000', address:'123 Retail Ave' });

  // Generate 25 Dynamic Products
  console.log('Generating 25 dynamic E-Commerce products...');
  const dynamicProducts = [];
  const categories = ['Electronics', 'Fashion', 'Home', 'Beauty', 'Sports'];
  
  for (let i = 0; i < 25; i++) {
    dynamicProducts.push({
      name: faker.commerce.productName(),
      price: parseInt(faker.commerce.price({ min: 1000, max: 150000 })),
      description: faker.commerce.productDescription(),
      stock: faker.number.int({ min: 5, max: 250 }),
      category: faker.helpers.arrayElement(categories),
      rating: faker.number.float({ min: 3.5, max: 5.0, fractionDigits: 1 }),
      reviews: faker.number.int({ min: 0, max: 5000 }),
      image: faker.image.urlLoremFlickr({ category: 'product', width: 400, height: 400 })
    });
  }
  await Product.insertMany(dynamicProducts);

  // Generate 5 dynamic additional Users
  console.log('Generating 5 dynamic customer profiles...');
  const dynamicUsers = [];
  for (let i = 0; i < 5; i++) {
    dynamicUsers.push({
      name: faker.person.fullName(),
      email: faker.internet.email().toLowerCase(),
      password: hashedCustomer,
      role: 'customer',
      phone: faker.phone.number({ style: 'national' }),
      address: faker.location.streetAddress()
    });
  }
  await User.insertMany(dynamicUsers);

  console.log('Generating activity history logs...');
  await ActivityLog.create([
    { type:'user',    message:'ShopNova Admin account securely created', time:'just now' },
    { type:'product', message:'Catalog aggressively expanded with 25 dynamic products via Faker.js', time:'just now' },
    { type:'user',    message:'New user cluster imported', time:'1 min ago' }
  ]);

  console.log('🎉 Seeding successfully completed to Atlas!');
  process.exit();
}

seed().catch(e => { console.error('Seeding failed:', e); process.exit(1); });
