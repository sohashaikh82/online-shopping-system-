const mongoose = require('mongoose');
const fs = require('fs');
require('dotenv').config({ path: '.env' });

const uri = process.env.MONGO_URI;

mongoose.connect(uri, { serverSelectionTimeoutMS: 5000 })
  .then(() => {
    fs.writeFileSync('mongoError.txt', 'SUCCESS!');
    console.log('SUCCESS');
    process.exit(0);
  })
  .catch(err => {
    fs.writeFileSync('mongoError.txt', err.message || err.toString());
    console.error(err);
    process.exit(1);
  });
