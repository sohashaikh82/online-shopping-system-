const localtunnel = require('localtunnel');
const fs = require('fs');

(async () => {
  const tunnel = await localtunnel({ port: 3000 });
  fs.writeFileSync('tunnel_url.txt', tunnel.url);
  console.log('Tunnel URL:', tunnel.url);
  
  tunnel.on('close', () => {
    // tunnels are closed
  });
})();
