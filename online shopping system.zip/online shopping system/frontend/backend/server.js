const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'fallback_secret';

app.use(cors({ origin: '*' }));
app.use(express.json());

// Serve frontend folder as static files
app.use(express.static(path.join(__dirname, '..', '..', 'frontend')));

// ─── In-Memory Data ────────────────────────────────────────────────────────
let users = [
  { id: 'u1', name: 'Alice Johnson', email: 'alice@email.com', password: bcrypt.hashSync('password123', 8), phone: '9876543210', address: '123 Main St, Mumbai', role: 'customer', createdAt: new Date('2024-01-10') },
  { id: 'u2', name: 'Bob Smith',     email: 'bob@email.com',   password: bcrypt.hashSync('password123', 8), phone: '9123456789', address: '45 Park Ave, Delhi',  role: 'customer', createdAt: new Date('2024-02-15') },
  { id: 'admin1', name: 'Admin User', email: 'admin@shopnova.com', password: bcrypt.hashSync('admin123', 8), phone: '9000000000', address: 'HQ', role: 'admin', createdAt: new Date('2023-12-01') }
];

let products = [
  { id: 'p1',  name: 'Apple iPhone 15 Pro',       price: 134900, description: '48MP camera, A17 Pro chip, Titanium design. 256GB storage.',  stock: 45,  category: 'Electronics', rating: 4.8, reviews: 1240,  image: 'https://images.unsplash.com/photo-1696446702183-a0f297a34e9c?w=400&q=80' },
  { id: 'p2',  name: 'Samsung Galaxy S24 Ultra',   price: 129999, description: 'Galaxy AI, 200MP camera, S Pen included. 512GB.',               stock: 30,  category: 'Electronics', rating: 4.7, reviews: 890,   image: 'https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?w=400&q=80' },
  { id: 'p3',  name: 'Sony WH-1000XM5 Headphones', price: 29990,  description: 'Industry-leading noise cancellation, 30hr battery.',           stock: 120, category: 'Electronics', rating: 4.9, reviews: 3200,  image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&q=80' },
  { id: 'p4',  name: 'Nike Air Max 270',            price: 12995,  description: 'Max Air cushioning for all-day comfort. 6 colors.',            stock: 200, category: 'Fashion',     rating: 4.5, reviews: 5600,  image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&q=80' },
  { id: 'p5',  name: 'MacBook Air M3',              price: 114900, description: '15-hr battery, 8GB RAM, 256GB SSD, Retina display.',           stock: 25,  category: 'Electronics', rating: 4.9, reviews: 2100,  image: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400&q=80' },
  { id: 'p6',  name: "Levi's 511 Slim Jeans",       price: 3499,   description: 'Classic slim fit, stretch fabric, multiple washes.',           stock: 500, category: 'Fashion',     rating: 4.3, reviews: 8900,  image: 'https://images.unsplash.com/photo-1542272604-787c3835535d?w=400&q=80' },
  { id: 'p7',  name: 'Instant Pot Duo 7-in-1',      price: 9999,   description: 'Pressure cooker, slow cooker, rice cooker & more. 6qt.',      stock: 80,  category: 'Home',        rating: 4.7, reviews: 12000, image: 'https://images.unsplash.com/photo-1585515320310-259814833e62?w=400&q=80' },
  { id: 'p8',  name: 'Canon EOS R50 Camera',        price: 74990,  description: 'Mirrorless, 24.2MP, 4K video, RF-S 18-45mm lens kit.',        stock: 18,  category: 'Electronics', rating: 4.6, reviews: 430,   image: 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=400&q=80' },
  { id: 'p9',  name: 'Dyson V15 Detect Vacuum',     price: 59900,  description: 'Laser detects hidden dust, HEPA filtration, 60min.',          stock: 35,  category: 'Home',        rating: 4.8, reviews: 1870,  image: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&q=80' },
  { id: 'p10', name: 'Adidas Ultraboost 23',         price: 17999,  description: 'BOOST midsole, Primeknit+ upper, Continental outsole.',       stock: 150, category: 'Fashion',     rating: 4.6, reviews: 3400,  image: 'https://images.unsplash.com/photo-1608231387042-66d1773070a5?w=400&q=80' },
  { id: 'p11', name: 'iPad Air M2',                  price: 69900,  description: '11-inch Liquid Retina, M2 chip, 5G capable, USB-C.',          stock: 60,  category: 'Electronics', rating: 4.8, reviews: 980,   image: 'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=400&q=80' },
  { id: 'p12', name: 'Philips Air Fryer XL',         price: 8999,   description: '6.2L capacity, TurboStar technology, 7 presets.',            stock: 90,  category: 'Home',        rating: 4.4, reviews: 6700,  image: 'https://images.unsplash.com/photo-1648136654826-e7b4c13bc92f?w=400&q=80' },
];

let orders = [
  { id: 'ord001', userId: 'u1', items: [{ productId:'p1', name:'Apple iPhone 15 Pro',       price:134900, qty:1, image:'https://images.unsplash.com/photo-1696446702183-a0f297a34e9c?w=400&q=80' }], total:134900, status:'Delivered',  paymentMethod:'UPI',         paymentStatus:'Paid', date: new Date('2024-03-01'), address:'123 Main St, Mumbai' },
  { id: 'ord002', userId: 'u1', items: [{ productId:'p3', name:'Sony WH-1000XM5 Headphones', price:29990,  qty:1, image:'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&q=80' }], total:29990,  status:'Shipped',    paymentMethod:'Credit Card', paymentStatus:'Paid', date: new Date('2024-03-18'), address:'123 Main St, Mumbai' },
  { id: 'ord003', userId: 'u2', items: [{ productId:'p4', name:'Nike Air Max 270',            price:12995,  qty:2, image:'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&q=80' }], total:25990,  status:'Processing', paymentMethod:'Net Banking', paymentStatus:'Paid', date: new Date('2024-03-20'), address:'45 Park Ave, Delhi'  },
  { id: 'ord004', userId: 'u2', items: [{ productId:'p5', name:'MacBook Air M3',              price:114900, qty:1, image:'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400&q=80' }], total:114900, status:'Pending',    paymentMethod:'EMI',         paymentStatus:'Paid', date: new Date('2024-03-22'), address:'45 Park Ave, Delhi'  },
];

let carts = {};

let activityLog = [
  { type:'order',   message:'New order #ord004 placed by Bob Smith – ₹1,14,900', time:'2 mins ago' },
  { type:'user',    message:'New customer Alice Johnson registered',               time:'1 hour ago' },
  { type:'payment', message:'Payment received for order #ord003 – ₹25,990',       time:'3 hours ago' },
  { type:'order',   message:'Order #ord001 delivered to Alice Johnson',            time:'1 day ago'   },
  { type:'product', message:'Stock updated: MacBook Air M3 – 25 units',           time:'2 days ago'  },
];

// ─── Auth Middleware ───────────────────────────────────────────────────────
const auth = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'Unauthorized' });
  try { req.user = jwt.verify(token, JWT_SECRET); next(); }
  catch { res.status(401).json({ error: 'Invalid token' }); }
};
const adminOnly = (req, res, next) => {
  if (req.user?.role !== 'admin') return res.status(403).json({ error: 'Admin access only' });
  next();
};

// ─── AUTH ──────────────────────────────────────────────────────────────────
app.post('/api/auth/signup', async (req, res) => {
  try {
    const { name, email, password, phone, address } = req.body;
    if (!name || !email || !password) return res.status(400).json({ error: 'Name, email and password are required' });
    if (users.find(u => u.email === email)) return res.status(409).json({ error: 'Email already registered' });
    const hashed = await bcrypt.hash(password, 8);
    const user = { id: uuidv4(), name, email, password: hashed, phone: phone||'', address: address||'', role: 'customer', createdAt: new Date() };
    users.push(user);
    activityLog.unshift({ type:'user', message:`New customer ${name} registered`, time:'just now' });
    const token = jwt.sign({ id:user.id, name:user.name, email:user.email, role:user.role }, JWT_SECRET, { expiresIn:'7d' });
    res.json({ token, user: { id:user.id, name:user.name, email:user.email, role:user.role } });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = users.find(u => u.email === email);
    if (!user || !await bcrypt.compare(password, user.password)) return res.status(401).json({ error: 'Invalid email or password' });
    const token = jwt.sign({ id:user.id, name:user.name, email:user.email, role:user.role }, JWT_SECRET, { expiresIn:'7d' });
    res.json({ token, user: { id:user.id, name:user.name, email:user.email, role:user.role } });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// ─── PRODUCTS ──────────────────────────────────────────────────────────────
app.get('/api/products', (req, res) => {
  let result = [...products];
  const { search, category, maxPrice, sort } = req.query;
  if (search)    result = result.filter(p => p.name.toLowerCase().includes(search.toLowerCase()) || p.description.toLowerCase().includes(search.toLowerCase()));
  if (category && category !== 'All') result = result.filter(p => p.category === category);
  if (maxPrice)  result = result.filter(p => p.price <= Number(maxPrice));
  if (sort === 'price_asc')  result.sort((a,b) => a.price - b.price);
  if (sort === 'price_desc') result.sort((a,b) => b.price - a.price);
  if (sort === 'rating')     result.sort((a,b) => b.rating - a.rating);
  res.json(result);
});

app.get('/api/products/:id', (req, res) => {
  const p = products.find(p => p.id === req.params.id);
  if (!p) return res.status(404).json({ error: 'Product not found' });
  res.json(p);
});

// ─── CART ──────────────────────────────────────────────────────────────────
app.get('/api/cart', auth, (req, res) => res.json(carts[req.user.id] || []));

app.post('/api/cart/add', auth, (req, res) => {
  const { productId, qty } = req.body;
  const product = products.find(p => p.id === productId);
  if (!product) return res.status(404).json({ error: 'Product not found' });
  if (!carts[req.user.id]) carts[req.user.id] = [];
  const existing = carts[req.user.id].find(i => i.productId === productId);
  if (existing) existing.qty += qty || 1;
  else carts[req.user.id].push({ productId, name:product.name, price:product.price, qty:qty||1, image:product.image });
  res.json(carts[req.user.id]);
});

app.put('/api/cart/update', auth, (req, res) => {
  const { productId, qty } = req.body;
  if (!carts[req.user.id]) return res.json([]);
  if (qty <= 0) carts[req.user.id] = carts[req.user.id].filter(i => i.productId !== productId);
  else { const item = carts[req.user.id].find(i => i.productId === productId); if (item) item.qty = qty; }
  res.json(carts[req.user.id]);
});

app.delete('/api/cart/remove/:productId', auth, (req, res) => {
  if (carts[req.user.id]) carts[req.user.id] = carts[req.user.id].filter(i => i.productId !== req.params.productId);
  res.json(carts[req.user.id] || []);
});

app.delete('/api/cart/clear', auth, (req, res) => {
  carts[req.user.id] = [];
  res.json([]);
});

// ─── ORDERS ────────────────────────────────────────────────────────────────
app.post('/api/orders', auth, (req, res) => {
  const { paymentMethod, address } = req.body;
  const cartItems = carts[req.user.id] || [];
  if (!cartItems.length) return res.status(400).json({ error: 'Cart is empty' });
  const total = cartItems.reduce((s, i) => s + i.price * i.qty, 0);
  const newOrder = {
    id: 'ord' + uuidv4().slice(0,6).toUpperCase(),
    userId: req.user.id, items: [...cartItems], total,
    status: 'Processing', paymentMethod, paymentStatus: 'Paid',
    date: new Date(), address
  };
  orders.unshift(newOrder);
  carts[req.user.id] = [];
  activityLog.unshift({ type:'order', message:`New order ${newOrder.id} placed by ${req.user.name} – ₹${total.toLocaleString('en-IN')}`, time:'just now' });
  res.json(newOrder);
});

app.get('/api/orders', auth, (req, res) => {
  const result = req.user.role === 'admin' ? orders : orders.filter(o => o.userId === req.user.id);
  res.json(result);
});

app.get('/api/orders/:id', auth, (req, res) => {
  const order = orders.find(o => o.id === req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found' });
  if (req.user.role !== 'admin' && order.userId !== req.user.id) return res.status(403).json({ error: 'Forbidden' });
  res.json(order);
});

// ─── ADMIN ─────────────────────────────────────────────────────────────────
app.get('/api/admin/dashboard', auth, adminOnly, (req, res) => {
  const totalRevenue = orders.filter(o => o.paymentStatus === 'Paid').reduce((s, o) => s + o.total, 0);
  res.json({
    totalUsers: users.filter(u => u.role === 'customer').length,
    totalProducts: products.length,
    totalOrders: orders.length,
    totalRevenue,
    recentOrders: orders.slice(0, 5),
    activityLog: activityLog.slice(0, 8),
  });
});

app.get('/api/admin/customers', auth, adminOnly, (req, res) => {
  res.json(users.filter(u => u.role === 'customer').map(u => ({
    id: u.id, name: u.name, email: u.email, phone: u.phone,
    address: u.address, createdAt: u.createdAt,
    orders: orders.filter(o => o.userId === u.id).length
  })));
});

app.post('/api/admin/products', auth, adminOnly, (req, res) => {
  const { name, price, description, stock, category, image } = req.body;
  if (!name || !price) return res.status(400).json({ error: 'Name and price required' });
  const p = { id:'p'+uuidv4().slice(0,6), name, price:Number(price), description:description||'', stock:Number(stock)||0, category:category||'Other', rating:4.0, reviews:0, image:image||'' };
  products.push(p);
  activityLog.unshift({ type:'product', message:`Product "${name}" added by admin`, time:'just now' });
  res.json(p);
});

app.put('/api/admin/products/:id', auth, adminOnly, (req, res) => {
  const idx = products.findIndex(p => p.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  products[idx] = { ...products[idx], ...req.body };
  res.json(products[idx]);
});

app.delete('/api/admin/products/:id', auth, adminOnly, (req, res) => {
  products = products.filter(p => p.id !== req.params.id);
  res.json({ success: true });
});

app.put('/api/admin/orders/:id/status', auth, adminOnly, (req, res) => {
  const order = orders.find(o => o.id === req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found' });
  order.status = req.body.status;
  activityLog.unshift({ type:'order', message:`Order ${order.id} status → "${req.body.status}"`, time:'just now' });
  res.json(order);
});

// Catch-all: serve frontend
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '..', '..', 'frontend', 'index.html'));
});

app.listen(PORT, () => {
  console.log('\n╔══════════════════════════════════════════╗');
  console.log('║   🚀 ShopNova Server Started!             ║');
  console.log(`║   🌐 http://localhost:${PORT}               ║`);
  console.log('╠══════════════════════════════════════════╣');
  console.log('║  👤 Customer: alice@email.com / password123║');
  console.log('║  🔑 Admin:    admin@shopnova.com / admin123 ║');
  console.log('╚══════════════════════════════════════════╝\n');
});
