require('dotenv').config();
const mongoose = require('mongoose');

mongoose.connect(process.env.MONGO_URI, { serverSelectionTimeoutMS: 5000 })
  .then(() => {
    console.log('--- CONNECTION SUCCESSFUL ---');
    process.exit(0);
  })
  .catch(err => {
    console.error('--- CONNECTION FAILED ---');
    console.error(err.message);
    process.exit(1);
  });
