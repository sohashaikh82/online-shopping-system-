/* ═══════════════════════════════════════════════════
   ShopNova – Frontend App (Part 1)
   Core state, helpers, auth, home, product detail
═══════════════════════════════════════════════════ */
const API = '/api';

// ── State ────────────────────────────────────────────
let state = {
  user:   JSON.parse(localStorage.getItem('sn_user') || 'null'),
  token:  localStorage.getItem('sn_token') || null,
  cart: [], products: [],
  filterCat: 'All', filterSort: '', filterMax: 200000, searchTerm: '',
  adminSection: 'dashboard', checkoutPayment: 'UPI',
};

// ── Helpers ──────────────────────────────────────────
const $   = id => document.getElementById(id);
const fmt = n  => '₹' + Number(n).toLocaleString('en-IN');
const hdrs = () => ({ 'Content-Type':'application/json', ...(state.token ? { Authorization:'Bearer '+state.token } : {}) });

async function api(method, path, body) {
  const res  = await fetch(API + path, { method, headers: hdrs(), body: body ? JSON.stringify(body) : undefined });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

function toast(msg, type = '') {
  const t = $('toast');
  t.textContent = msg; t.className = 'toast show ' + type;
  setTimeout(() => t.className = 'toast', 3500);
}

function stars(r) {
  const f = Math.floor(r), h = r % 1 >= .5;
  return '★'.repeat(f) + (h ? '½' : '') + '☆'.repeat(5 - f - (h?1:0));
}

function openModal(html) { $('modal-content').innerHTML = html; $('modal-overlay').classList.remove('hidden'); }
function closeModal()    { $('modal-overlay').classList.add('hidden'); }

function saveAuth(token, user) {
  state.token = token; state.user = user;
  localStorage.setItem('sn_token', token);
  localStorage.setItem('sn_user', JSON.stringify(user));
}
function logout() {
  state.token = null; state.user = null; state.cart = [];
  localStorage.removeItem('sn_token'); localStorage.removeItem('sn_user');
  updateNavUI(); navigate('home');
}
function updateNavUI() {
  const u = state.user;
  $('navUserName').textContent = u ? u.name.split(' ')[0] : 'Account';
  $('authNavBtn').textContent  = u ? 'Logout' : 'Login';
  $('authNavBtn').onclick      = u ? logout : () => navigate('auth');
  $('adminLink').classList.toggle('hidden', !u || u.role !== 'admin');
  updateCartBadge();
}
function updateCartBadge() {
  $('cartBadge').textContent = state.cart.reduce((s,i) => s + i.qty, 0);
}

// ── Router ───────────────────────────────────────────
function navigate(page, data) {
  document.querySelectorAll('.page').forEach(p => p.classList.add('hidden'));
  $('page-' + page).classList.remove('hidden');
  window.scrollTo(0, 0);
  if (page==='home')     renderHome();
  if (page==='auth')     renderAuth();
  if (page==='product')  renderProduct(data);
  if (page==='cart')     renderCart();
  if (page==='checkout') renderCheckout();
  if (page==='orders')   renderOrders();
  if (page==='profile')  renderProfile();
  if (page==='admin-login') renderAdminLogin();
  if (page==='admin')    renderAdmin();
}
function filterCat(cat) { state.filterCat = cat; navigate('home'); }
function doSearch() { state.searchTerm = $('searchInput').value; navigate('home'); }
$('searchInput').addEventListener('keydown', e => e.key === 'Enter' && doSearch());

// ── AUTH ─────────────────────────────────────────────
function renderAuth() {
  $('page-auth').innerHTML = `
  <div class="auth-card">
    <div class="auth-logo">⚡ ShopNova</div>
    <div class="auth-sub">Your premium shopping destination</div>
    <div class="auth-tabs">
      <div class="auth-tab active" id="tabLogin"  onclick="switchTab('login')">Login</div>
      <div class="auth-tab"        id="tabSignup" onclick="switchTab('signup')">Sign Up</div>
    </div>
    <div id="authForm"></div>
  </div>`;
  renderLoginForm();
}
function switchTab(tab) {
  $('tabLogin').classList.toggle('active',  tab==='login');
  $('tabSignup').classList.toggle('active', tab==='signup');
  tab==='login' ? renderLoginForm() : renderSignupForm();
}
function renderLoginForm() {
  $('authForm').innerHTML = `
    <div class="form-group"><label>Email</label>
      <input class="form-control" id="liEmail" type="email" value="alice@email.com" /></div>
    <div class="form-group"><label>Password</label>
      <input class="form-control" id="liPass" type="password" value="password123" /></div>
    <button class="btn btn-primary btn-full" style="margin-top:8px" onclick="doLogin()">Login</button>
    <div class="auth-divider">staff portal</div>
    <button class="btn btn-outline btn-full" onclick="navigate('admin-login')">🛡️ Go to Admin Portal Dashboard</button>
    <div class="auth-switch">No account? <span onclick="switchTab('signup')">Sign up free</span></div>`;
}
function renderAdminLogin() {
  $('page-admin-login').innerHTML = `
  <div class="auth-card" style="border-top:4px solid var(--warning)">
    <div class="auth-logo" style="color:var(--text)">🛡️ Admin Portal</div>
    <div class="auth-sub">Secure login for staff and administrators</div>
    <div id="adminAuthForm">
      <div class="form-group"><label>Admin Email</label>
        <input class="form-control" id="aEmail" type="email" value="admin@shopnova.com" /></div>
      <div class="form-group"><label>Security Code</label>
        <input class="form-control" id="aPass" type="password" value="admin123" /></div>
      <button class="btn btn-primary btn-full" style="margin-top:20px;background:var(--warning);color:var(--dark3)" onclick="quickLogin($('aEmail').value,$('aPass').value)">Authorize & Enter Dashboard</button>
      <div class="auth-divider">Not an admin?</div>
      <button class="btn btn-outline btn-full" onclick="navigate('auth')">← Return to Store Login</button>
    </div>
  </div>`;
}
function renderSignupForm() {
  $('authForm').innerHTML = `
    <div class="form-group"><label>Full Name</label><input class="form-control" id="suName" placeholder="Your full name" /></div>
    <div class="form-group"><label>Email</label><input class="form-control" id="suEmail" type="email" placeholder="you@email.com" /></div>
    <div class="form-group"><label>Password</label><input class="form-control" id="suPass" type="password" placeholder="Min. 6 characters" /></div>
    <div class="form-group"><label>Phone</label><input class="form-control" id="suPhone" placeholder="10-digit mobile" /></div>
    <div class="form-group"><label>Address</label><input class="form-control" id="suAddr" placeholder="House, Street, City" /></div>
    <button class="btn btn-primary btn-full" style="margin-top:8px" onclick="doSignup()">Create Account</button>
    <div class="auth-switch">Already a member? <span onclick="switchTab('login')">Login here</span></div>`;
}
async function doLogin() {
  try {
    const { token, user } = await api('POST', '/auth/login', { email:$('liEmail').value, password:$('liPass').value });
    saveAuth(token, user); await loadCart(); updateNavUI();
    toast('Welcome back, ' + user.name.split(' ')[0] + '! 👋', 'success');
    navigate(user.role==='admin' ? 'admin' : 'home');
  } catch(e) { toast(e.message, 'error'); }
}
async function quickLogin(email, pass) {
  $('liEmail').value = email; $('liPass').value = pass; await doLogin();
}
async function doSignup() {
  try {
    const { token, user } = await api('POST', '/auth/signup', {
      name:$('suName').value, email:$('suEmail').value, password:$('suPass').value,
      phone:$('suPhone').value, address:$('suAddr').value
    });
    saveAuth(token, user); await loadCart(); updateNavUI();
    toast('Welcome to ShopNova! 🎉', 'success'); navigate('home');
  } catch(e) { toast(e.message, 'error'); }
}

// ── Cart Loader ──────────────────────────────────────
async function loadCart() {
  if (!state.token) { state.cart = []; updateCartBadge(); return; }
  try { state.cart = await api('GET', '/cart'); updateCartBadge(); } catch { state.cart = []; }
}
async function addToCart(productId, qty = 1) {
  if (!state.token) { toast('Please login to add items', 'error'); navigate('auth'); return; }
  state.cart = await api('POST', '/cart/add', { productId, qty });
  updateCartBadge(); toast('Added to cart! 🛒', 'success');
}

// ── HOME ─────────────────────────────────────────────
async function renderHome() {
  $('page-home').innerHTML = `
  <div class="hero">
    <div class="hero-inner">
      <div class="hero-badge">🔥 Best Deals · New Arrivals</div>
      <h1>Shop Smarter,<br><span>Live Better</span></h1>
      <p>Discover millions of products from top brands — fast delivery, easy returns, unbeatable prices.</p>
      <div class="hero-actions">
        <button class="btn btn-primary" onclick="document.getElementById('prodSec').scrollIntoView({behavior:'smooth'})">Shop Now →</button>
        <button class="btn btn-outline" onclick="navigate('orders')">Track Orders</button>
      </div>
      <div class="hero-stats">
        <div class="hero-stat"><h3>2M+</h3><p>Products</p></div>
        <div class="hero-stat"><h3>500K+</h3><p>Customers</p></div>
        <div class="hero-stat"><h3>24hr</h3><p>Delivery</p></div>
        <div class="hero-stat"><h3>4.8★</h3><p>Rating</p></div>
      </div>
    </div>
  </div>
  <div class="filter-bar">
    <span class="filter-label">Category:</span>
    <select id="catSel" onchange="state.filterCat=this.value;renderProdSec()">
      <option value="All">All Categories</option>
      <option value="Electronics">Electronics</option>
      <option value="Fashion">Fashion</option>
      <option value="Home">Home & Kitchen</option>
    </select>
    <span class="filter-label">Sort:</span>
    <select id="sortSel" onchange="state.filterSort=this.value;renderProdSec()">
      <option value="">Featured</option>
      <option value="price_asc">Price: Low → High</option>
      <option value="price_desc">Price: High → Low</option>
      <option value="rating">Top Rated</option>
    </select>
    <div class="price-range-wrap">
      <span class="filter-label">Max Price:</span>
      <input type="range" id="priceRange" min="1000" max="200000" step="1000" value="${state.filterMax}"
        oninput="state.filterMax=+this.value;$('priceVal').textContent=fmt(this.value);renderProdSec()" />
      <span id="priceVal">${fmt(state.filterMax)}</span>
    </div>
  </div>
  <div class="container"><div id="prodSec"></div></div>
  <footer>© 2024 ShopNova · All rights reserved</footer>`;

  if (state.filterCat !== 'All') $('catSel').value = state.filterCat;
  if (state.filterSort)          $('sortSel').value = state.filterSort;
  await renderProdSec();
}

async function renderProdSec() {
  const sec = $('prodSec'); if (!sec) return;
  sec.innerHTML = '<div class="spinner"></div>';
  try {
    const p = new URLSearchParams();
    if (state.searchTerm)        p.set('search',   state.searchTerm);
    if (state.filterCat!=='All') p.set('category', state.filterCat);
    if (state.filterSort)        p.set('sort',     state.filterSort);
    p.set('maxPrice', state.filterMax);
    state.products = await api('GET', '/products?' + p.toString());
    const label = state.searchTerm
      ? `Results for "<span>${state.searchTerm}</span>"`
      : `<span>${state.filterCat==='All' ? 'All Products' : state.filterCat}</span>`;
    sec.innerHTML = `
      <div class="section-header">
        <h2 class="section-title">${label}</h2>
        <span class="text-muted" style="font-size:.85rem">${state.products.length} products</span>
      </div>
      <div class="products-grid">${state.products.map(productCard).join('')}</div>`;
  } catch(e) { sec.innerHTML = `<p style="text-align:center;color:var(--danger);padding:40px">${e.message}</p>`; }
}

function productCard(p) {
  const bdg  = p.reviews>5000 ? `<div class="product-badge hot">HOT</div>` : p.stock<20 ? `<div class="product-badge">Low Stock</div>` : `<div class="product-badge new">NEW</div>`;
  const stk  = p.stock>20 ? `<span class="in-stock">✓ In Stock</span>` : p.stock>0 ? `<span class="low-stock">⚠ Only ${p.stock} left</span>` : `<span class="out-stock">✗ Out of Stock</span>`;
  const old  = Math.round(p.price * 1.18);
  return `
  <div class="product-card" onclick="navigate('product','${p.id}')">
    <div class="product-img-wrap">
      <img src="${p.image}" alt="${p.name}" loading="lazy" onerror="this.src='https://placehold.co/400x300/1e1e24/ff6b00?text=Product'" />
      ${bdg}
    </div>
    <div class="product-info">
      <div class="product-cat">${p.category}</div>
      <div class="product-name">${p.name}</div>
      <div class="product-rating"><span class="stars">${stars(p.rating)}</span><span class="rating-count">(${p.reviews.toLocaleString()})</span></div>
      <div class="product-price">${fmt(p.price)}<span class="old-price">${fmt(old)}</span></div>
      <div class="product-stock">${stk}</div>
    </div>
    <div class="product-actions">
      <button class="btn btn-primary"  onclick="event.stopPropagation();addToCart('${p.id}')">Add to Cart</button>
      <button class="btn btn-outline"  onclick="event.stopPropagation();navigate('product','${p.id}')">Details</button>
    </div>
  </div>`;
}

// ── PRODUCT DETAIL ───────────────────────────────────
async function renderProduct(id) {
  const w = $('page-product');
  w.innerHTML = '<div class="container"><div class="spinner"></div></div>';
  try {
    const p   = await api('GET', '/products/' + id);
    const old = Math.round(p.price * 1.18);
    const stk = p.stock>20 ? `<span class="in-stock">✓ In Stock (${p.stock} units)</span>` : p.stock>0 ? `<span class="low-stock">⚠ Only ${p.stock} left!</span>` : `<span class="out-stock">✗ Out of Stock</span>`;
    w.innerHTML = `
    <div class="container">
      <div style="padding:20px 0 0;font-size:.83rem;color:var(--muted)">
        <span style="cursor:pointer;color:var(--primary)" onclick="navigate('home')">Home</span> › ${p.category} › ${p.name}
      </div>
      <div class="product-detail">
        <div class="detail-img-wrap">
          <img src="${p.image}" alt="${p.name}" onerror="this.src='https://placehold.co/600x600/1e1e24/ff6b00?text=Product'" />
        </div>
        <div class="detail-info">
          <div class="product-cat" style="font-size:.8rem;margin-bottom:8px">${p.category}</div>
          <h1>${p.name}</h1>
          <div class="product-rating" style="margin:10px 0">
            <span class="stars" style="font-size:1rem">${stars(p.rating)}</span>
            <span style="font-size:.88rem;color:var(--muted)">${p.rating} · ${p.reviews.toLocaleString()} reviews</span>
          </div>
          <div class="detail-price">${fmt(p.price)} <span style="font-size:1rem;color:var(--muted);text-decoration:line-through;font-weight:400">${fmt(old)}</span></div>
          <div style="background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.3);border-radius:8px;padding:10px 14px;margin-bottom:18px;font-size:.85rem">
            💰 You save ${fmt(old-p.price)} (${Math.round(((old-p.price)/old)*100)}% off)
          </div>
          <div class="detail-meta">
            <p>${stk}</p>
            <p><strong>About:</strong> ${p.description}</p>
          </div>
          <div class="qty-control">
            <span style="font-size:.88rem;color:var(--muted)">Qty:</span>
            <button class="qty-btn" onclick="chgQty(-1)">−</button>
            <span class="qty-num" id="detQty">1</span>
            <button class="qty-btn" onclick="chgQty(1)">+</button>
          </div>
          <div style="display:flex;flex-direction:column;gap:10px">
            <button class="btn btn-primary btn-full" style="padding:14px" onclick="addToCart('${p.id}',+$('detQty').textContent)">🛒 Add to Cart</button>
            <button class="btn btn-outline btn-full" style="padding:14px" onclick="buyNow('${p.id}')">⚡ Buy Now</button>
          </div>
          <div style="display:flex;gap:16px;margin-top:20px;flex-wrap:wrap">
            <span style="font-size:.8rem;color:var(--muted)">🚚 Free delivery</span>
            <span style="font-size:.8rem;color:var(--muted)">↩ Easy returns</span>
            <span style="font-size:.8rem;color:var(--muted)">🔒 Secure payment</span>
          </div>
        </div>
      </div>
    </div>
    <footer>© 2024 ShopNova · All rights reserved</footer>`;
  } catch(e) { w.innerHTML = `<div class="container" style="padding:60px;text-align:center;color:var(--danger)">${e.message}</div>`; }
}
function chgQty(d) { const e=$('detQty'); e.textContent=Math.max(1,+e.textContent+d); }
async function buyNow(id) { await addToCart(id, +$('detQty').textContent); navigate('checkout'); }
