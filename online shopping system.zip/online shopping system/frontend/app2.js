/* ═══════════════════════════════════════════════════
   ShopNova – Frontend App (Part 2)
   Cart, Checkout, Orders, Profile, Admin, Init
═══════════════════════════════════════════════════ */

// ── CART ──────────────────────────────────────────────
async function renderCart() {
  const w = $('page-cart');
  await loadCart();
  const cart = state.cart;
  if (!cart.length) {
    w.innerHTML = `<div class="cart-empty container"><div style="font-size:4rem">🛒</div><h2>Your cart is empty</h2><p>Browse our products and add items you love.</p><button class="btn btn-primary" onclick="navigate('home')">Continue Shopping</button></div>`;
    return;
  }
  const sub = cart.reduce((s,i) => s+i.price*i.qty, 0);
  w.innerHTML = `
  <div class="container">
    <div class="cart-layout">
      <div>
        <div class="flex-between" style="margin-bottom:16px">
          <h2 style="font-size:1.3rem;font-weight:800">Shopping Cart <span style="color:var(--muted);font-size:.9rem">(${cart.length} items)</span></h2>
          <button class="btn btn-outline btn-sm" onclick="clearCart()">🗑 Clear All</button>
        </div>
        <div class="card">
          ${cart.map(i=>`
          <div class="cart-item">
            <img src="${i.image}" alt="${i.name}" onerror="this.src='https://placehold.co/90x90/1e1e24/ff6b00?text=P'" />
            <div class="cart-item-info">
              <div class="cart-item-name">${i.name}</div>
              <div class="cart-item-price">${fmt(i.price)}</div>
              <div style="display:flex;align-items:center;gap:10px;margin-top:10px">
                <button class="qty-btn" style="width:28px;height:28px" onclick="updQty('${i.productId}',${i.qty-1})">−</button>
                <span style="font-weight:700">${i.qty}</span>
                <button class="qty-btn" style="width:28px;height:28px" onclick="updQty('${i.productId}',${i.qty+1})">+</button>
              </div>
            </div>
            <div style="text-align:right;min-width:100px">
              <div style="font-weight:800;color:var(--primary)">${fmt(i.price*i.qty)}</div>
              <button class="btn btn-outline btn-sm" style="margin-top:8px;color:var(--danger);border-color:var(--danger)" onclick="rmItem('${i.productId}')">Remove</button>
            </div>
          </div>`).join('')}
        </div>
        <div style="margin-top:14px"><button class="btn btn-outline" onclick="navigate('home')">← Continue Shopping</button></div>
      </div>
      <div class="cart-summary">
        <h3>Order Summary</h3>
        <div class="summary-row"><span>Subtotal (${cart.reduce((s,i)=>s+i.qty,0)} items)</span><span>${fmt(sub)}</span></div>
        <div class="summary-row"><span>Delivery</span><span style="color:var(--success)">FREE</span></div>
        <div class="summary-row total"><span>TOTAL</span><span>${fmt(sub)}</span></div>
        <button class="btn btn-primary btn-full" style="margin-top:18px;padding:14px;font-size:1rem" onclick="navigate('checkout')">Proceed to Checkout →</button>
        <div style="margin-top:14px;font-size:.78rem;color:var(--muted);text-align:center">🔒 Secured by ShopNova Pay</div>
      </div>
    </div>
  </div>
  <footer>© 2024 ShopNova · All rights reserved</footer>`;
}
async function updQty(pid, qty) { state.cart = await api('PUT','/cart/update',{productId:pid,qty}); updateCartBadge(); renderCart(); }
async function rmItem(pid)      { state.cart = await api('DELETE','/cart/remove/'+pid); updateCartBadge(); renderCart(); toast('Item removed'); }
async function clearCart()      { state.cart = await api('DELETE','/cart/clear'); updateCartBadge(); renderCart(); toast('Cart cleared'); }

// ── CHECKOUT ──────────────────────────────────────────
function renderCheckout() {
  const w = $('page-checkout');
  if (!state.token) { navigate('auth'); return; }
  if (!state.cart.length) { navigate('cart'); return; }
  const cart = state.cart, sub = cart.reduce((s,i)=>s+i.price*i.qty,0), u = state.user;
  const payOpts = [
    {id:'UPI',icon:'📱',label:'UPI / Google Pay / PhonePe'},
    {id:'Credit Card',icon:'💳',label:'Credit / Debit Card'},
    {id:'Net Banking',icon:'🏦',label:'Net Banking'},
    {id:'EMI',icon:'📅',label:'EMI (No-Cost on select cards)'},
    {id:'COD',icon:'💵',label:'Cash on Delivery'},
  ];
  w.innerHTML = `
  <div class="container">
    <h2 style="padding:28px 0 18px;font-size:1.4rem;font-weight:800">🔒 Secure Checkout</h2>
    <div class="checkout-layout">
      <div>
        <div class="checkout-section">
          <h3>📍 Delivery Address</h3>
          <div class="form-group"><label>Full Name</label><input class="form-control" id="ckName" value="${u.name}" /></div>
          <div class="form-group"><label>Delivery Address</label><textarea class="form-control" id="ckAddr" rows="3" placeholder="House no., Street, City, PIN"></textarea></div>
          <div class="form-group"><label>Phone Number</label><input class="form-control" id="ckPhone" placeholder="10-digit mobile" /></div>
        </div>
        <div class="checkout-section">
          <h3>💳 Payment Method</h3>
          <div class="payment-methods">
            ${payOpts.map(p=>`
            <label class="payment-opt ${state.checkoutPayment===p.id?'selected':''}">
              <input type="radio" name="pay" value="${p.id}" ${state.checkoutPayment===p.id?'checked':''}
                onchange="state.checkoutPayment=this.value;document.querySelectorAll('.payment-opt').forEach(e=>e.classList.remove('selected'));this.closest('.payment-opt').classList.add('selected')" />
              <span class="pay-icon">${p.icon}</span>
              <span class="payment-opt-label">${p.label}</span>
            </label>`).join('')}
          </div>
          <div class="trust-badges">
            <div class="trust-badge">🔒 SSL Encrypted</div>
            <div class="trust-badge">✓ 100% Safe</div>
            <div class="trust-badge">↩ Easy Refund</div>
          </div>
        </div>
      </div>
      <div>
        <div class="cart-summary">
          <h3>Order Summary</h3>
          ${cart.map(i=>`
          <div style="display:flex;gap:10px;margin-bottom:12px;align-items:center">
            <img src="${i.image}" style="width:48px;height:48px;border-radius:8px;object-fit:cover" onerror="this.src='https://placehold.co/48?text=P'" />
            <div style="flex:1;font-size:.82rem">${i.name} <span style="color:var(--muted)">×${i.qty}</span></div>
            <div style="font-size:.85rem;font-weight:700">${fmt(i.price*i.qty)}</div>
          </div>`).join('')}
          <div class="divider"></div>
          <div class="summary-row"><span>Subtotal</span><span>${fmt(sub)}</span></div>
          <div class="summary-row"><span>Delivery</span><span style="color:var(--success)">FREE</span></div>
          <div class="summary-row total"><span>TOTAL</span><span>${fmt(sub)}</span></div>
          <button class="btn btn-primary btn-full" style="margin-top:18px;padding:14px;font-size:1rem" onclick="placeOrder()">🛍 Place Order – ${fmt(sub)}</button>
          <div style="margin-top:10px;font-size:.75rem;color:var(--muted);text-align:center">By placing order you agree to our Terms</div>
        </div>
      </div>
    </div>
  </div>
  <footer>© 2024 ShopNova · All rights reserved</footer>`;
}

async function placeOrder() {
  const addr = $('ckAddr').value.trim();
  if (!addr) { toast('Please enter delivery address', 'error'); return; }
  try {
    const order = await api('POST', '/orders', { paymentMethod: state.checkoutPayment, address: addr });
    state.cart = []; updateCartBadge();
    toast('Order placed! 🎉', 'success');
    openModal(`
    <div style="text-align:center;padding:20px 0">
      <div style="font-size:3.5rem">🎉</div>
      <h2 style="margin:16px 0 8px">Order Confirmed!</h2>
      <p style="color:var(--muted);margin-bottom:6px">Order <strong style="color:var(--primary)">#${order.id}</strong> placed successfully.</p>
      <p style="color:var(--muted);font-size:.88rem;margin-bottom:24px">Estimated delivery: 2–4 business days</p>
      <div style="background:var(--dark3);border-radius:10px;padding:16px;margin-bottom:20px;font-size:.88rem">
        <div class="summary-row"><span>Total Paid</span><span style="color:var(--primary);font-weight:700">${fmt(order.total)}</span></div>
        <div class="summary-row"><span>Payment</span><span>${order.paymentMethod}</span></div>
        <div class="summary-row" style="margin:0"><span>Status</span><span class="status-badge status-Processing">${order.status}</span></div>
      </div>
      <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap">
        <button class="btn btn-primary" onclick="closeModal();navigate('orders')">View My Orders</button>
        <button class="btn btn-outline" onclick="closeModal();navigate('home')">Continue Shopping</button>
      </div>
    </div>`);
  } catch(e) { toast(e.message, 'error'); }
}

// ── ORDERS ────────────────────────────────────────────
async function renderOrders() {
  const w = $('page-orders');
  if (!state.token) {
    w.innerHTML = `<div class="container" style="padding:60px;text-align:center"><p>Please <span style="color:var(--primary);cursor:pointer" onclick="navigate('auth')">login</span> to view your orders.</p></div>`;
    return;
  }
  w.innerHTML = '<div class="container"><div class="spinner"></div></div>';
  try {
    const orders = await api('GET', '/orders');
    const steps  = ['Pending','Processing','Shipped','Delivered'];
    w.innerHTML = `
    <div class="container orders-wrap">
      <h2 style="font-size:1.4rem;font-weight:800;margin-bottom:22px">📦 My Orders <span style="color:var(--muted);font-size:.9rem">(${orders.length})</span></h2>
      ${!orders.length ? `<div style="text-align:center;padding:60px;color:var(--muted)">No orders yet. <span style="color:var(--primary);cursor:pointer" onclick="navigate('home')">Start shopping!</span></div>` :
        orders.map(o => {
          const step = steps.indexOf(o.status);
          return `
          <div class="order-card">
            <div class="order-header">
              <div><div class="order-id">#${o.id}</div><div class="order-date">${new Date(o.date).toLocaleDateString('en-IN',{day:'numeric',month:'long',year:'numeric'})}</div></div>
              <div style="display:flex;align-items:center;gap:12px">
                <span class="status-badge status-${o.status.replace(' ','')}">${o.status}</span>
                <span style="font-size:.8rem;color:var(--muted)">${o.paymentMethod}</span>
              </div>
            </div>
            ${o.status!=='Cancelled'?`
            <div class="order-track">
              ${steps.map((s,i)=>`
              <div class="track-step" style="flex:${i<steps.length-1?'1':'0 0 auto'}">
                <div class="track-row">
                  <div class="track-dot ${i<step?'done':i===step?'active':''}">${i<step?'✓':i===step?'●':''}</div>
                  ${i<steps.length-1?`<div class="track-line ${i<step?'done':''}"></div>`:''}
                </div>
                <div class="track-label">${s}</div>
              </div>`).join('')}
            </div>`:''}
            <div class="order-items">
              ${o.items.map(it=>`
              <div class="order-item">
                <img src="${it.image}" alt="${it.name}" onerror="this.src='https://placehold.co/60?text=P'" />
                <div class="order-item-info"><div class="order-item-name">${it.name}</div><div class="order-item-price">${fmt(it.price)} × ${it.qty}</div></div>
                <div style="font-weight:700">${fmt(it.price*it.qty)}</div>
              </div>`).join('')}
            </div>
            <div class="order-footer">
              <div style="font-size:.83rem;color:var(--muted)">📍 ${o.address}</div>
              <div class="order-total">Total: ${fmt(o.total)}</div>
            </div>
          </div>`;
        }).join('')}
    </div>
    <footer>© 2024 ShopNova · All rights reserved</footer>`;
  } catch(e) { w.innerHTML = `<div class="container" style="padding:60px;text-align:center;color:var(--danger)">${e.message}</div>`; }
}

// ── PROFILE ───────────────────────────────────────────
function renderProfile() {
  if (!state.user) { navigate('auth'); return; }
  const u = state.user, init = u.name.split(' ').map(n=>n[0]).join('').slice(0,2).toUpperCase();
  $('page-profile').innerHTML = `
  <div class="container">
    <div class="profile-layout">
      <div class="profile-sidebar">
        <div class="profile-avatar">${init}</div>
        <div class="profile-name">${u.name}</div>
        <div class="profile-email">${u.email}</div>
        <div style="background:rgba(255,107,0,.1);border:1px solid rgba(255,107,0,.3);border-radius:8px;padding:5px 14px;font-size:.78rem;color:var(--primary);margin-bottom:20px;display:inline-block">
          ${u.role==='admin'?'🔑 Administrator':'🧑 Customer'}
        </div>
        <div class="profile-nav">
          <div class="profile-nav-item active">👤 Personal Info</div>
          <div class="profile-nav-item" onclick="navigate('orders')">📦 My Orders</div>
          <div class="profile-nav-item" onclick="navigate('cart')">🛒 My Cart</div>
          ${u.role==='admin'?`<div class="profile-nav-item" onclick="navigate('admin')">⚙️ Admin Panel</div>`:''}
          <div class="profile-nav-item" style="color:var(--danger)" onclick="logout()">🚪 Logout</div>
        </div>
      </div>
      <div class="profile-content">
        <div class="profile-section">
          <h3>Personal Information</h3>
          <div class="info-grid">
            <div class="info-item"><label>Full Name</label><span>${u.name}</span></div>
            <div class="info-item"><label>Email</label><span>${u.email}</span></div>
            <div class="info-item"><label>Role</label><span style="text-transform:capitalize">${u.role}</span></div>
            <div class="info-item"><label>Member Since</label><span>2024</span></div>
          </div>
        </div>
        <div class="profile-section">
          <h3>Quick Actions</h3>
          <div style="display:flex;gap:10px;flex-wrap:wrap">
            <button class="btn btn-primary" onclick="navigate('orders')">📦 My Orders</button>
            <button class="btn btn-outline" onclick="navigate('cart')">🛒 View Cart</button>
            <button class="btn btn-outline" onclick="navigate('home')">🛍 Shop Now</button>
            ${u.role==='admin'?`<button class="btn btn-outline" onclick="navigate('admin')">⚙️ Admin Panel</button>`:''}
            <button class="btn btn-outline" style="color:var(--danger);border-color:var(--danger)" onclick="logout()">🚪 Logout</button>
          </div>
        </div>
      </div>
    </div>
  </div>
  <footer>© 2024 ShopNova · All rights reserved</footer>`;
}

// ── ADMIN ─────────────────────────────────────────────
async function renderAdmin() {
  const w = $('page-admin');
  if (!state.user || state.user.role !== 'admin') { toast('Admin access required','error'); navigate('home'); return; }
  const navItems = [{id:'dashboard',icon:'📊',label:'Dashboard'},{id:'products',icon:'📦',label:'Products'},{id:'customers',icon:'👥',label:'Customers'},{id:'orders',icon:'🛍',label:'Orders'},{id:'payments',icon:'💰',label:'Payment Monitoring'}];
  w.innerHTML = `
  <div class="admin-layout">
    <div class="admin-sidebar">
      <div class="admin-sidebar-logo">⚡ ShopNova Admin</div>
      ${navItems.map(n=>`<div class="admin-nav-item ${state.adminSection===n.id?'active':''}" id="anav_${n.id}" onclick="adminNav('${n.id}')"><span class="nav-icon">${n.icon}</span>${n.label}</div>`).join('')}
      <div style="margin-top:20px"><div class="admin-nav-item" style="color:var(--danger)" onclick="logout()"><span class="nav-icon">🚪</span>Logout</div></div>
    </div>
    <div class="admin-main" id="adminMain"><div class="spinner"></div></div>
  </div>`;
  await loadAdminSec();
}
function adminNav(sec) {
  state.adminSection = sec;
  document.querySelectorAll('.admin-nav-item').forEach(el => el.classList.remove('active'));
  const el = $('anav_'+sec); if (el) el.classList.add('active');
  loadAdminSec();
}
async function loadAdminSec() {
  const main = $('adminMain'); if (!main) return;
  main.innerHTML = '<div class="spinner"></div>';
  try {
    if (state.adminSection==='dashboard') await adminDashboard(main);
    if (state.adminSection==='products')  await adminProducts(main);
    if (state.adminSection==='customers') await adminCustomers(main);
    if (state.adminSection==='orders')    await adminOrders(main);
    if (state.adminSection==='payments')  await adminPayments(main);
  } catch(e) { main.innerHTML=`<p style="color:var(--danger)">${e.message}</p>`; }
}

async function adminDashboard(main) {
  const d = await api('GET','/admin/dashboard');
  main.innerHTML = `
  <div class="admin-page-title">📊 Dashboard</div>
  <div class="stat-cards">
    ${[{icon:'👥',val:d.totalUsers,label:'Customers',ch:'+12% this month'},{icon:'📦',val:d.totalProducts,label:'Products',ch:'+3 today'},{icon:'🛍',val:d.totalOrders,label:'Orders',ch:'+8% this week'},{icon:'💰',val:fmt(d.totalRevenue),label:'Revenue',ch:'+22% vs last month'}]
      .map(s=>`<div class="stat-card"><div class="stat-icon">${s.icon}</div><div class="stat-val">${s.val}</div><div class="stat-label">${s.label}</div><div class="stat-change">↑ ${s.ch}</div></div>`).join('')}
  </div>
  <div class="admin-grid2">
    <div class="admin-table-wrap">
      <div class="admin-table-header"><h3>Recent Orders</h3></div>
      <div style="overflow:auto"><table class="data-table">
        <thead><tr><th>Order ID</th><th>Amount</th><th>Status</th><th>Method</th></tr></thead>
        <tbody>${d.recentOrders.map(o=>`<tr>
          <td style="color:var(--primary);font-weight:600">#${o.id}</td>
          <td style="font-weight:700">${fmt(o.total)}</td>
          <td><span class="status-badge status-${o.status.replace(' ','')}">${o.status}</span></td>
          <td style="font-size:.82rem;color:var(--muted)">${o.paymentMethod}</td>
        </tr>`).join('')}</tbody>
      </table></div>
    </div>
    <div class="activity-panel">
      <h3>⚡ Activity Log</h3>
      ${d.activityLog.map(a=>`
      <div class="activity-item">
        <div class="act-icon ${a.type}">${{order:'🛍',user:'👤',payment:'💰',product:'📦'}[a.type]||'📋'}</div>
        <div class="act-msg">${a.message}</div>
        <div class="act-time">${a.time}</div>
      </div>`).join('')}
    </div>
  </div>`;
}

async function adminProducts(main) {
  const prods = await api('GET','/products');
  main.innerHTML = `
  <div class="admin-page-title">📦 Products</div>
  <div class="admin-table-wrap">
    <div class="admin-table-header"><h3>All Products (${prods.length})</h3><button class="btn btn-primary btn-sm" onclick="openAddProd()">+ Add Product</button></div>
    <div style="overflow:auto"><table class="data-table">
      <thead><tr><th>Image</th><th>Name</th><th>Category</th><th>Price</th><th>Stock</th><th>Rating</th><th>Actions</th></tr></thead>
      <tbody>${prods.map(p=>`<tr>
        <td><img src="${p.image}" style="width:44px;height:44px;object-fit:cover;border-radius:7px" onerror="this.src='https://placehold.co/44?text=P'" /></td>
        <td style="font-weight:600;max-width:180px">${p.name}</td>
        <td><span style="background:rgba(255,107,0,.1);color:var(--primary);padding:3px 9px;border-radius:5px;font-size:.75rem">${p.category}</span></td>
        <td style="font-weight:700">${fmt(p.price)}</td>
        <td><span class="${p.stock>20?'in-stock':p.stock>0?'low-stock':'out-stock'}">${p.stock}</span></td>
        <td>${p.rating}★</td>
        <td style="white-space:nowrap">
          <button class="btn btn-outline btn-sm" style="margin-right:6px" onclick="openEditProd('${p.id}')">Edit</button>
          <button class="btn btn-danger btn-sm" onclick="delProd('${p.id}')">Del</button>
        </td>
      </tr>`).join('')}</tbody>
    </table></div>
  </div>`;
}

async function adminCustomers(main) {
  const custs = await api('GET','/admin/customers');
  main.innerHTML = `
  <div class="admin-page-title">👥 Customers</div>
  <div class="admin-table-wrap">
    <div class="admin-table-header"><h3>All Customers (${custs.length})</h3></div>
    <div style="overflow:auto"><table class="data-table">
      <thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Orders</th><th>Joined</th></tr></thead>
      <tbody>${custs.map(c=>`<tr>
        <td><div style="display:flex;align-items:center;gap:10px">
          <div style="width:32px;height:32px;border-radius:50%;background:linear-gradient(135deg,var(--primary),#ff9500);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:.75rem;color:#fff">
            ${c.name.split(' ').map(n=>n[0]).join('').slice(0,2)}
          </div>
          <span style="font-weight:600">${c.name}</span>
        </div></td>
        <td style="color:var(--muted)">${c.email}</td>
        <td>${c.phone||'—'}</td>
        <td><span style="background:rgba(59,130,246,.15);color:var(--info);padding:3px 10px;border-radius:99px;font-size:.8rem;font-weight:700">${c.orders}</span></td>
        <td style="font-size:.82rem;color:var(--muted)">${new Date(c.createdAt).toLocaleDateString('en-IN')}</td>
      </tr>`).join('')}</tbody>
    </table></div>
  </div>`;
}

async function adminOrders(main) {
  const orders = await api('GET','/orders');
  main.innerHTML = `
  <div class="admin-page-title">🛍 All Orders</div>
  <div class="admin-table-wrap">
    <div class="admin-table-header"><h3>All Orders (${orders.length})</h3></div>
    <div style="overflow:auto"><table class="data-table">
      <thead><tr><th>Order ID</th><th>Items</th><th>Total</th><th>Payment</th><th>Status</th><th>Date</th><th>Update</th></tr></thead>
      <tbody>${orders.map(o=>`<tr>
        <td style="color:var(--primary);font-weight:600">#${o.id}</td>
        <td style="color:var(--muted)">${o.items.length} item(s)</td>
        <td style="font-weight:700">${fmt(o.total)}</td>
        <td style="font-size:.82rem">${o.paymentMethod}</td>
        <td><span class="status-badge status-${o.status.replace(' ','')}">${o.status}</span></td>
        <td style="font-size:.78rem;color:var(--muted)">${new Date(o.date).toLocaleDateString('en-IN')}</td>
        <td><select class="form-control" style="padding:5px 9px;font-size:.8rem;border-radius:7px;min-width:120px" onchange="updOrderStatus('${o.id}',this.value)">
          ${['Pending','Processing','Shipped','Delivered','Cancelled'].map(s=>`<option ${s===o.status?'selected':''}>${s}</option>`).join('')}
        </select></td>
      </tr>`).join('')}</tbody>
    </table></div>
  </div>`;
}

async function adminPayments(main) {
  const orders = await api('GET','/orders');
  main.innerHTML = `
  <div class="admin-page-title">💰 Payment Monitoring</div>
  <div class="stat-cards">
    <div class="stat-card"><div class="stat-icon">💳</div><div class="stat-val">${orders.filter(o=>o.paymentMethod==='Credit Card').length}</div><div class="stat-label">Card Transactions</div></div>
    <div class="stat-card"><div class="stat-icon">📱</div><div class="stat-val">${orders.filter(o=>o.paymentMethod==='UPI').length}</div><div class="stat-label">UPI Transactions</div></div>
    <div class="stat-card"><div class="stat-icon">💵</div><div class="stat-val">${orders.filter(o=>o.paymentMethod==='COD').length}</div><div class="stat-label">Cash on Delivery</div></div>
  </div>
  <div class="admin-table-wrap" style="margin-top:20px">
    <div class="admin-table-header"><h3>Recent Payment Transactions</h3></div>
    <div style="overflow:auto"><table class="data-table">
      <thead><tr><th>Txn Date</th><th>Order Ref</th><th>Customer</th><th>Payment Method</th><th>Amount Collected</th><th>Payment Status</th></tr></thead>
      <tbody>${orders.map(o=>`<tr>
        <td style="color:var(--muted)">${new Date(o.date).toLocaleString('en-IN')}</td>
        <td style="font-weight:700">ORD-${o.id.toUpperCase()}</td>
        <td>Verified Buyer</td>
        <td style="font-weight:600">${o.paymentMethod}</td>
        <td style="color:var(--primary);font-weight:800">${fmt(o.total)}</td>
        <td><span class="status-badge ${o.status==='Cancelled'?'status-Cancelled':'status-Delivered'}">${o.status==='Cancelled'?'Refunded':'Completed'}</span></td>
      </tr>`).join('')}</tbody>
    </table></div>
  </div>`;
}

async function updOrderStatus(id, status) {
  try { await api('PUT','/admin/orders/'+id+'/status',{status}); toast(`Status updated → ${status}`,'success'); }
  catch(e) { toast(e.message,'error'); }
}

function openAddProd() {
  openModal(`
  <h3 style="margin-bottom:20px">➕ Add New Product</h3>
  <div class="form-group"><label>Name</label><input class="form-control" id="ap_n" placeholder="Product name" /></div>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
    <div class="form-group"><label>Price (₹)</label><input class="form-control" id="ap_p" type="number" placeholder="29999" /></div>
    <div class="form-group"><label>Stock</label><input class="form-control" id="ap_s" type="number" placeholder="100" /></div>
  </div>
  <div class="form-group"><label>Category</label><select class="form-control" id="ap_c"><option>Electronics</option><option>Fashion</option><option>Home</option><option>Other</option></select></div>
  <div class="form-group"><label>Description</label><textarea class="form-control" id="ap_d" rows="3" placeholder="Product description…"></textarea></div>
  <div class="form-group"><label>Image URL</label><input class="form-control" id="ap_i" placeholder="https://…" /></div>
  <button class="btn btn-primary btn-full" style="margin-top:8px" onclick="submitAddProd()">Add Product</button>`);
}
async function submitAddProd() {
  try {
    await api('POST','/admin/products',{name:$('ap_n').value,price:$('ap_p').value,stock:$('ap_s').value,category:$('ap_c').value,description:$('ap_d').value,image:$('ap_i').value});
    closeModal(); toast('Product added ✅','success'); await loadAdminSec();
  } catch(e) { toast(e.message,'error'); }
}
async function openEditProd(id) {
  const p = await api('GET','/products/'+id);
  openModal(`
  <h3 style="margin-bottom:20px">✏️ Edit Product</h3>
  <div class="form-group"><label>Name</label><input class="form-control" id="ep_n" value="${p.name}" /></div>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
    <div class="form-group"><label>Price (₹)</label><input class="form-control" id="ep_p" type="number" value="${p.price}" /></div>
    <div class="form-group"><label>Stock</label><input class="form-control" id="ep_s" type="number" value="${p.stock}" /></div>
  </div>
  <div class="form-group"><label>Description</label><textarea class="form-control" id="ep_d" rows="3">${p.description}</textarea></div>
  <div class="form-group"><label>Image URL</label><input class="form-control" id="ep_i" value="${p.image}" /></div>
  <button class="btn btn-primary btn-full" style="margin-top:8px" onclick="submitEditProd('${p.id}')">Save Changes</button>`);
}
async function submitEditProd(id) {
  try {
    await api('PUT','/admin/products/'+id,{name:$('ep_n').value,price:+$('ep_p').value,stock:+$('ep_s').value,description:$('ep_d').value,image:$('ep_i').value});
    closeModal(); toast('Product updated ✅','success'); await loadAdminSec();
  } catch(e) { toast(e.message,'error'); }
}
async function delProd(id) {
  if (!confirm('Delete this product?')) return;
  await api('DELETE','/admin/products/'+id);
  toast('Product deleted','success'); await loadAdminSec();
}

// ── INIT ──────────────────────────────────────────────
(async function init() {
  updateNavUI();
  await loadCart();
  navigate('home');
})();
