/* ═══════════════════════════════════════════════════════════════════════════
   ShopNova – Frontend Application
   All pages rendered client-side, communicating with Express API
═══════════════════════════════════════════════════════════════════════════ */

const API = 'http://localhost:3000/api';

// ─── State ────────────────────────────────────────────────────────────────────
let state = {
  user: JSON.parse(localStorage.getItem('sn_user') || 'null'),
  token: localStorage.getItem('sn_token') || null,
  cart: [],
  products: [],
  currentProduct: null,
  currentPage: 'home',
  adminSection: 'dashboard',
  checkoutAddress: '',
  checkoutPayment: 'UPI',
  filterCat: 'All',
  filterSort: '',
  filterMax: 200000,
  searchTerm: '',
};

// ─── Helpers ──────────────────────────────────────────────────────────────────
const $ = id => document.getElementById(id);
const fmt = n => '₹' + Number(n).toLocaleString('en-IN');
const headers = () => ({ 'Content-Type': 'application/json', ...(state.token ? { Authorization: 'Bearer ' + state.token } : {}) });

async function api(method, path, body) {
  const res = await fetch(API + path, { method, headers: headers(), body: body ? JSON.stringify(body) : undefined });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

function toast(msg, type = '') {
  const t = $('toast');
  t.textContent = msg;
  t.className = 'toast show ' + type;
  setTimeout(() => t.className = 'toast', 3500);
}

function stars(r) {
  const full = Math.floor(r), half = r % 1 >= .5;
  return '★'.repeat(full) + (half ? '½' : '') + '☆'.repeat(5 - full - (half ? 1 : 0));
}

function statusStep(status) {
  const steps = ['Pending', 'Processing', 'Shipped', 'Delivered'];
  return steps.indexOf(status);
}

function openModal(html) {
  $('modal-content').innerHTML = html;
  $('modal-overlay').classList.remove('hidden');
}
function closeModal() { $('modal-overlay').classList.add('hidden'); }

function saveAuth(token, user) {
  state.token = token; state.user = user;
  localStorage.setItem('sn_token', token);
  localStorage.setItem('sn_user', JSON.stringify(user));
}
function logout() {
  state.token = null; state.user = null; state.cart = [];
  localStorage.removeItem('sn_token'); localStorage.removeItem('sn_user');
  updateNavUI(); navigate('auth');
}

function updateNavUI() {
  const u = state.user;
  $('navUserName').textContent = u ? u.name.split(' ')[0] : 'Account';
  $('authNavBtn').textContent  = u ? 'Logout' : 'Login';
  $('authNavBtn').onclick       = u ? logout : () => navigate('auth');
  $('adminLink').classList.toggle('hidden', !u || u.role !== 'admin');
  updateCartBadge();
}

function updateCartBadge() {
  const total = state.cart.reduce((s, i) => s + i.qty, 0);
  $('cartBadge').textContent = total;
}

// ─── Router ───────────────────────────────────────────────────────────────────
function navigate(page, data) {
  document.querySelectorAll('.page').forEach(p => p.classList.add('hidden'));
  $('page-' + page).classList.remove('hidden');
  state.currentPage = page;
  window.scrollTo(0, 0);
  if (page === 'home')     renderHome();
  if (page === 'auth')     renderAuth();
  if (page === 'product')  renderProduct(data);
  if (page === 'cart')     renderCart();
  if (page === 'checkout') renderCheckout();
  if (page === 'orders')   renderOrders();
  if (page === 'profile')  renderProfile();
  if (page === 'admin')    renderAdmin();
}

function filterCat(cat) { state.filterCat = cat; navigate('home'); }
function doSearch() { state.searchTerm = $('searchInput').value; navigate('home'); }
$('searchInput').addEventListener('keydown', e => e.key === 'Enter' && doSearch());

// ─── AUTH PAGE ────────────────────────────────────────────────────────────────
function renderAuth() {
  $('page-auth').innerHTML = `
  <div class="auth-card">
    <div class="auth-logo">⚡ ShopNova</div>
    <div class="auth-sub">Your premium shopping destination</div>
    <div class="auth-tabs">
      <div class="auth-tab active" id="tabLogin" onclick="switchAuthTab('login')">Login</div>
      <div class="auth-tab" id="tabSignup" onclick="switchAuthTab('signup')">Sign Up</div>
    </div>
    <div id="authForm"></div>
  </div>`;
  renderLoginForm();
}

function switchAuthTab(tab) {
  $('tabLogin').classList.toggle('active', tab === 'login');
  $('tabSignup').classList.toggle('active', tab === 'signup');
  tab === 'login' ? renderLoginForm() : renderSignupForm();
}

function renderLoginForm() {
  $('authForm').innerHTML = `
    <div class="form-group"><label>Email Address</label>
      <input class="form-control" type="email" id="loginEmail" placeholder="you@email.com" value="alice@email.com" /></div>
    <div class="form-group"><label>Password</label>
      <input class="form-control" type="password" id="loginPassword" placeholder="••••••••" value="password123" /></div>
    <button class="btn btn-primary btn-full" style="margin-top:8px" onclick="doLogin()">Login to Account</button>
    <div class="auth-divider">or try</div>
    <button class="btn btn-outline btn-full" onclick="quickLogin('admin@shopnova.com','admin123')">🔑 Login as Admin</button>
    <div class="auth-switch">No account? <span onclick="switchAuthTab('signup')">Sign up free</span></div>`;
}

function renderSignupForm() {
  $('authForm').innerHTML = `
    <div class="form-group"><label>Full Name</label>
      <input class="form-control" id="sigName" placeholder="Your full name" /></div>
    <div class="form-group"><label>Email Address</label>
      <input class="form-control" type="email" id="sigEmail" placeholder="you@email.com" /></div>
    <div class="form-group"><label>Password</label>
      <input class="form-control" type="password" id="sigPassword" placeholder="Min. 6 characters" /></div>
    <div class="form-group"><label>Phone</label>
      <input class="form-control" id="sigPhone" placeholder="10-digit mobile number" /></div>
    <div class="form-group"><label>Delivery Address</label>
      <input class="form-control" id="sigAddress" placeholder="House no., Street, City" /></div>
    <button class="btn btn-primary btn-full" style="margin-top:8px" onclick="doSignup()">Create Account</button>
    <div class="auth-switch">Already a member? <span onclick="switchAuthTab('login')">Login here</span></div>`;
}

async function doLogin() {
  try {
    const { token, user } = await api('POST', '/auth/login', { email: $('loginEmail').value, password: $('loginPassword').value });
    saveAuth(token, user); await loadCart(); updateNavUI();
    toast('Welcome back, ' + user.name.split(' ')[0] + '! 👋', 'success');
    navigate(user.role === 'admin' ? 'admin' : 'home');
  } catch(e) { toast(e.message, 'error'); }
}

async function quickLogin(email, pass) {
  $('loginEmail').value = email; $('loginPassword').value = pass; await doLogin();
}

async function doSignup() {
  try {
    const { token, user } = await api('POST', '/auth/signup', {
      name: $('sigName').value, email: $('sigEmail').value, password: $('sigPassword').value,
      phone: $('sigPhone').value, address: $('sigAddress').value
    });
    saveAuth(token, user); await loadCart(); updateNavUI();
    toast('Account created! Welcome to ShopNova 🎉', 'success');
    navigate('home');
  } catch(e) { toast(e.message, 'error'); }
}

// ─── CART LOADER ──────────────────────────────────────────────────────────────
async function loadCart() {
  if (!state.token) { state.cart = []; updateCartBadge(); return; }
  state.cart = await api('GET', '/cart');
  updateCartBadge();
}

// ─── ADD TO CART ──────────────────────────────────────────────────────────────
async function addToCart(productId, qty = 1) {
  if (!state.token) { toast('Please login to add items to cart', 'error'); navigate('auth'); return; }
  state.cart = await api('POST', '/cart/add', { productId, qty });
  updateCartBadge();
  toast('Added to cart! 🛒', 'success');
}

// ─── HOME PAGE ────────────────────────────────────────────────────────────────
async function renderHome() {
  const wrap = $('page-home');
  wrap.innerHTML = `
  <div class="hero">
    <div class="hero-inner">
      <div class="hero-badge">🔥 New Arrivals & Best Deals</div>
      <h1>Shop Smarter,<br><span>Live Better</span></h1>
      <p>Discover millions of products from top brands. Fast delivery, easy returns, great prices.</p>
      <div class="hero-actions">
        <button class="btn btn-primary" onclick="document.getElementById('productsSection').scrollIntoView({behavior:'smooth'})">Shop Now →</button>
        <button class="btn btn-outline" onclick="navigate('orders')">Track Orders</button>
      </div>
      <div class="hero-stats">
        <div class="hero-stat"><h3>2M+</h3><p>Products</p></div>
        <div class="hero-stat"><h3>500K+</h3><p>Happy Customers</p></div>
        <div class="hero-stat"><h3>24hr</h3><p>Fast Delivery</p></div>
        <div class="hero-stat"><h3>4.8★</h3><p>App Rating</p></div>
      </div>
    </div>
  </div>
  <div class="filter-bar">
    <span class="filter-label">Category:</span>
    <select onchange="state.filterCat=this.value;renderProductsSection()" id="catSelect">
      <option value="All">All Categories</option>
      <option value="Electronics">Electronics</option>
      <option value="Fashion">Fashion</option>
      <option value="Home">Home & Kitchen</option>
    </select>
    <span class="filter-label">Sort:</span>
    <select onchange="state.filterSort=this.value;renderProductsSection()" id="sortSelect">
      <option value="">Featured</option>
      <option value="price_asc">Price: Low to High</option>
      <option value="price_desc">Price: High to Low</option>
      <option value="rating">Top Rated</option>
    </select>
    <div class="price-range-wrap">
      <span class="filter-label">Max Price:</span>
      <input type="range" id="priceRange" min="1000" max="200000" step="1000" value="200000"
        oninput="state.filterMax=+this.value;$('priceVal').textContent=fmt(this.value);renderProductsSection()" />
      <span id="priceVal">${fmt(200000)}</span>
    </div>
  </div>
  <div class="container">
    <div id="productsSection"></div>
  </div>
  <footer>© 2024 ShopNova. All rights reserved. | Built with ⚡ by ShopNova Team</footer>`;

  if (state.filterCat !== 'All') $('catSelect').value = state.filterCat;
  if (state.filterSort)          $('sortSelect').value = state.filterSort;

  await renderProductsSection();
}

async function renderProductsSection() {
  const sec = $('productsSection');
  if (!sec) return;
  sec.innerHTML = '<div class="spinner"></div>';
  try {
    const params = new URLSearchParams();
    if (state.searchTerm) params.set('search', state.searchTerm);
    if (state.filterCat !== 'All') params.set('category', state.filterCat);
    if (state.filterSort) params.set('sort', state.filterSort);
    params.set('maxPrice', state.filterMax);
    state.products = await api('GET', '/products?' + params.toString());
    const label = state.searchTerm ? `Results for "<span>${state.searchTerm}</span>"` : `<span>${state.filterCat === 'All' ? 'All Products' : state.filterCat}</span>`;
    sec.innerHTML = `
      <div class="section-header">
        <h2 class="section-title">${label}</h2>
        <span class="text-muted" style="font-size:.85rem">${state.products.length} products found</span>
      </div>
      <div class="products-grid">
        ${state.products.map(p => productCard(p)).join('')}
      </div>`;
  } catch(e) { sec.innerHTML = `<p style="text-align:center;color:var(--danger);padding:40px">${e.message}</p>`; }
}

function productCard(p) {
  const badge = p.reviews > 5000 ? '<div class="product-badge hot">HOT</div>' : p.stock < 20 ? '<div class="product-badge">Low Stock</div>' : '<div class="product-badge new">NEW</div>';
  const stock  = p.stock > 20 ? `<span class="in-stock">✓ In Stock</span>` : p.stock > 0 ? `<span class="low-stock">⚠ Only ${p.stock} left</span>` : `<span class="out-stock">✗ Out of Stock</span>`;
  const old    = Math.round(p.price * 1.18);
  return `
  <div class="product-card" onclick="navigate('product','${p.id}')">
    <div class="product-img-wrap">
      <img src="${p.image}" alt="${p.name}" loading="lazy" onerror="this.src='https://placehold.co/400x300/1e1e24/ff6b00?text=Product'" />
      ${badge}
    </div>
    <div class="product-info">
      <div class="product-cat">${p.category}</div>
      <div class="product-name">${p.name}</div>
      <div class="product-rating">
        <span class="stars">${stars(p.rating)}</span>
        <span class="rating-count">(${p.reviews.toLocaleString()})</span>
      </div>
      <div class="product-price">${fmt(p.price)} <span class="old-price">${fmt(old)}</span></div>
      <div class="product-stock">${stock}</div>
    </div>
    <div class="product-actions">
      <button class="btn btn-primary" onclick="event.stopPropagation();addToCart('${p.id}')">Add to Cart</button>
      <button class="btn btn-outline" onclick="event.stopPropagation();navigate('product','${p.id}')">Details</button>
    </div>
  </div>`;
}

// ─── PRODUCT DETAIL PAGE ──────────────────────────────────────────────────────
async function renderProduct(id) {
  const wrap = $('page-product');
  wrap.innerHTML = '<div class="container"><div class="spinner"></div></div>';
  try {
    const p = await api('GET', '/products/' + id);
    state.currentProduct = p;
    const old = Math.round(p.price * 1.18);
    const stock = p.stock > 20 ? `<span class="in-stock">✓ In Stock (${p.stock} units)</span>` : p.stock > 0 ? `<span class="low-stock">⚠ Only ${p.stock} left!</span>` : `<span class="out-stock">✗ Out of Stock</span>`;
    wrap.innerHTML = `
    <div class="container">
      <div style="padding:20px 0 0;font-size:.83rem;color:var(--text-muted)">
        <span style="cursor:pointer;color:var(--primary)" onclick="navigate('home')">Home</span> › ${p.category} › ${p.name}
      </div>
      <div class="product-detail">
        <div class="detail-img-wrap">
          <img src="${p.image}" alt="${p.name}" onerror="this.src='https://placehold.co/600x600/1e1e24/ff6b00?text=Product'" />
        </div>
        <div class="detail-info">
          <div class="product-cat" style="font-size:.8rem;margin-bottom:8px">${p.category}</div>
          <h1>${p.name}</h1>
          <div class="product-rating" style="margin:10px 0">
            <span class="stars" style="font-size:1rem">${stars(p.rating)}</span>
            <span style="font-size:.88rem;color:var(--text-muted)">${p.rating} (${p.reviews.toLocaleString()} reviews)</span>
          </div>
          <div class="detail-price">${fmt(p.price)} <span style="font-size:1rem;color:var(--text-muted);text-decoration:line-through;font-weight:400">${fmt(old)}</span></div>
          <div style="background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.3);border-radius:8px;padding:10px 14px;margin-bottom:18px;font-size:.85rem;">
            💰 You save ${fmt(old - p.price)} (${Math.round(((old-p.price)/old)*100)}% off)
          </div>
          <div class="detail-meta">
            <p>${stock}</p>
            <p><strong>Description:</strong> ${p.description}</p>
          </div>
          <div class="qty-control">
            <span style="font-size:.88rem;color:var(--text-muted);margin-right:4px">Qty:</span>
            <button class="qty-btn" onclick="changeQty(-1)">−</button>
            <span class="qty-num" id="detailQty">1</span>
            <button class="qty-btn" onclick="changeQty(1)">+</button>
          </div>
          <div style="display:flex;flex-direction:column;gap:10px">
            <button class="btn btn-primary btn-full" style="padding:14px" onclick="addToCart('${p.id}',+$('detailQty').textContent)">
              🛒 Add to Cart
            </button>
            <button class="btn btn-outline btn-full" style="padding:14px" onclick="buyNow('${p.id}')">
              ⚡ Buy Now
            </button>
          </div>
          <div style="display:flex;gap:16px;margin-top:20px;flex-wrap:wrap">
            <span style="font-size:.8rem;color:var(--text-muted)">🚚 Free delivery</span>
            <span style="font-size:.8rem;color:var(--text-muted)">↩ Easy returns</span>
            <span style="font-size:.8rem;color:var(--text-muted)">🔒 Secure payment</span>
          </div>
        </div>
      </div>
    </div>
    <footer>© 2024 ShopNova. All rights reserved.</footer>`;
  } catch(e) { wrap.innerHTML = `<div class="container" style="padding:60px 0;text-align:center">${e.message}</div>`; }
}

function changeQty(d) {
  const el = $('detailQty');
  const val = Math.max(1, (+el.textContent) + d);
  el.textContent = val;
}

async function buyNow(productId) {
  await addToCart(productId, +$('detailQty').textContent);
  navigate('checkout');
}
