
// ─── CART PAGE ────────────────────────────────────────────────────────────────
async function renderCart() {
  const wrap = $('page-cart');
  await loadCart();
  const cart = state.cart;

  if (!cart.length) {
    wrap.innerHTML = `
    <div class="cart-empty container">
      <div style="font-size:4rem">🛒</div>
      <h2>Your cart is empty</h2>
      <p>Add items to your cart to see them here.</p>
      <button class="btn btn-primary" onclick="navigate('home')">Continue Shopping</button>
    </div>`;
    return;
  }

  const subtotal = cart.reduce((s, i) => s + i.price * i.qty, 0);
  const delivery = 0;
  const total = subtotal + delivery;

  wrap.innerHTML = `
  <div class="container">
    <div class="cart-layout">
      <div>
        <div class="flex-between" style="margin-bottom:16px">
          <h2 style="font-size:1.3rem;font-weight:800">Shopping Cart <span style="color:var(--text-muted);font-size:.9rem">(${cart.length} items)</span></h2>
          <button class="btn btn-outline btn-sm" onclick="clearCart()">🗑 Clear All</button>
        </div>
        <div class="card">
          ${cart.map(item => `
          <div class="cart-item">
            <img src="${item.image}" alt="${item.name}" onerror="this.src='https://placehold.co/90x90/1e1e24/ff6b00?text=P'" />
            <div class="cart-item-info">
              <div class="cart-item-name">${item.name}</div>
              <div class="cart-item-price">${fmt(item.price)}</div>
              <div style="display:flex;align-items:center;gap:10px;margin-top:10px">
                <button class="qty-btn" style="width:28px;height:28px;font-size:.9rem" onclick="updateQty('${item.productId}',${item.qty-1})">−</button>
                <span style="font-weight:700">${item.qty}</span>
                <button class="qty-btn" style="width:28px;height:28px;font-size:.9rem" onclick="updateQty('${item.productId}',${item.qty+1})">+</button>
              </div>
            </div>
            <div style="text-align:right;min-width:100px">
              <div style="font-weight:800;color:var(--primary);font-size:1rem">${fmt(item.price * item.qty)}</div>
              <button class="btn btn-outline btn-sm" style="margin-top:8px;color:var(--danger);border-color:var(--danger)" onclick="removeItem('${item.productId}')">Remove</button>
            </div>
          </div>`).join('')}
        </div>
        <div style="margin-top:14px">
          <button class="btn btn-outline" onclick="navigate('home')">← Continue Shopping</button>
        </div>
      </div>
      <div class="cart-summary">
        <h3>Order Summary</h3>
        <div class="summary-row"><span>Subtotal (${cart.reduce((s,i)=>s+i.qty,0)} items)</span><span>${fmt(subtotal)}</span></div>
        <div class="summary-row"><span>Delivery</span><span style="color:var(--success)">FREE</span></div>
        <div class="summary-row"><span>Discount</span><span style="color:var(--success)">-${fmt(0)}</span></div>
        <div class="summary-row total"><span>TOTAL</span><span>${fmt(total)}</span></div>
        <button class="btn btn-primary btn-full" style="margin-top:18px;padding:14px;font-size:1rem" onclick="navigate('checkout')">
          Proceed to Checkout →
        </button>
        <div style="margin-top:14px;font-size:.78rem;color:var(--text-muted);text-align:center">🔒 Secure checkout powered by ShopNova Pay</div>
      </div>
    </div>
  </div>
  <footer>© 2024 ShopNova. All rights reserved.</footer>`;
}

async function updateQty(pid, qty) {
  state.cart = await api('PUT', '/cart/update', { productId: pid, qty });
  updateCartBadge(); renderCart();
}
async function removeItem(pid) {
  state.cart = await api('DELETE', '/cart/remove/' + pid);
  updateCartBadge(); renderCart();
  toast('Item removed from cart');
}
async function clearCart() {
  state.cart = await api('DELETE', '/cart/clear');
  updateCartBadge(); renderCart();
  toast('Cart cleared');
}

// ─── CHECKOUT PAGE ────────────────────────────────────────────────────────────
function renderCheckout() {
  const wrap = $('page-checkout');
  if (!state.token) { navigate('auth'); return; }
  const cart = state.cart;
  if (!cart.length) { navigate('cart'); return; }
  const subtotal = cart.reduce((s, i) => s + i.price * i.qty, 0);
  const u = state.user;

  wrap.innerHTML = `
  <div class="container">
    <h2 style="padding:28px 0 18px;font-size:1.4rem;font-weight:800">Secure Checkout</h2>
    <div class="checkout-layout">
      <div>
        <div class="checkout-section">
          <h3>📍 Delivery Address</h3>
          <div class="form-group">
            <label>Full Name</label>
            <input class="form-control" id="ckName" value="${u.name}" />
          </div>
          <div class="form-group">
            <label>Delivery Address</label>
            <textarea class="form-control" id="ckAddress" rows="3" style="resize:vertical">${state.checkoutAddress || ''}</textarea>
          </div>
          <div class="form-group">
            <label>Phone Number</label>
            <input class="form-control" id="ckPhone" placeholder="10-digit mobile" />
          </div>
        </div>

        <div class="checkout-section">
          <h3>💳 Payment Method</h3>
          <div class="payment-methods">
            ${[
              { id:'UPI',        icon:'📱', label:'UPI / Google Pay / PhonePe' },
              { id:'Credit Card',icon:'💳', label:'Credit / Debit Card' },
              { id:'Net Banking',icon:'🏦', label:'Net Banking' },
              { id:'EMI',        icon:'📅', label:'EMI (No Cost on select cards)' },
              { id:'COD',        icon:'💵', label:'Cash on Delivery' },
            ].map(p => `
            <label class="payment-opt ${state.checkoutPayment===p.id?'selected':''}">
              <input type="radio" name="payMethod" value="${p.id}" ${state.checkoutPayment===p.id?'checked':''} onchange="state.checkoutPayment=this.value;document.querySelectorAll('.payment-opt').forEach(el=>el.classList.remove('selected'));this.closest('.payment-opt').classList.add('selected')" />
              <span class="pay-icon">${p.icon}</span>
              <span class="payment-opt-label">${p.label}</span>
            </label>`).join('')}
          </div>
          <div class="trust-badges">
            <div class="trust-badge">🔒 SSL Secured</div>
            <div class="trust-badge">✓ 100% Safe</div>
            <div class="trust-badge">↩ Easy Refund</div>
          </div>
        </div>
      </div>

      <div>
        <div class="cart-summary">
          <h3>Order Summary</h3>
          ${cart.map(i=>`
          <div style="display:flex;gap:10px;margin-bottom:12px;align-items:center">
            <img src="${i.image}" style="width:48px;height:48px;border-radius:8px;object-fit:cover" onerror="this.src='https://placehold.co/48x48/1e1e24/ff6b00?text=P'" />
            <div style="flex:1;font-size:.82rem">${i.name} <span style="color:var(--text-muted)">×${i.qty}</span></div>
            <div style="font-size:.85rem;font-weight:700">${fmt(i.price*i.qty)}</div>
          </div>`).join('')}
          <div class="section-divider"></div>
          <div class="summary-row"><span>Subtotal</span><span>${fmt(subtotal)}</span></div>
          <div class="summary-row"><span>Delivery</span><span style="color:var(--success)">FREE</span></div>
          <div class="summary-row total"><span>TOTAL</span><span>${fmt(subtotal)}</span></div>
          <button class="btn btn-primary btn-full" style="margin-top:18px;padding:14px;font-size:1rem" onclick="placeOrder()">
            🛍 Place Order – ${fmt(subtotal)}
          </button>
          <div style="margin-top:10px;font-size:.75rem;color:var(--text-muted);text-align:center">By placing order you agree to our Terms & Conditions</div>
        </div>
      </div>
    </div>
  </div>
  <footer>© 2024 ShopNova. All rights reserved.</footer>`;
}

async function placeOrder() {
  const addr = $('ckAddress').value.trim();
  if (!addr) { toast('Please enter delivery address', 'error'); return; }
  try {
    const order = await api('POST', '/orders', { paymentMethod: state.checkoutPayment, address: addr });
    state.cart = []; updateCartBadge();
    toast('Order placed successfully! 🎉', 'success');
    openModal(`
      <div style="text-align:center;padding:20px 0">
        <div style="font-size:3.5rem">🎉</div>
        <h2 style="margin:16px 0 8px">Order Confirmed!</h2>
        <p style="color:var(--text-muted);margin-bottom:8px">Your order <strong style="color:var(--primary)">#${order.id}</strong> has been placed.</p>
        <p style="color:var(--text-muted);font-size:.88rem;margin-bottom:24px">Estimated delivery: 2-4 business days</p>
        <div style="background:var(--dark3);border-radius:10px;padding:16px;margin-bottom:20px;font-size:.88rem">
          <div class="summary-row"><span>Total Paid</span><span style="color:var(--primary);font-weight:700">${fmt(order.total)}</span></div>
          <div class="summary-row"><span>Payment</span><span>${order.paymentMethod}</span></div>
          <div class="summary-row" style="margin:0"><span>Status</span><span class="status-badge status-Processing">${order.status}</span></div>
        </div>
        <div style="display:flex;gap:10px;justify-content:center">
          <button class="btn btn-primary" onclick="closeModal();navigate('orders')">View My Orders</button>
          <button class="btn btn-outline" onclick="closeModal();navigate('home')">Continue Shopping</button>
        </div>
      </div>`);
  } catch(e) { toast(e.message, 'error'); }
}

// ─── ORDERS PAGE ──────────────────────────────────────────────────────────────
async function renderOrders() {
  const wrap = $('page-orders');
  if (!state.token) { wrap.innerHTML = `<div class="container" style="padding:60px 0;text-align:center"><p>Please <span style="color:var(--primary);cursor:pointer" onclick="navigate('auth')">login</span> to view orders.</p></div>`; return; }
  wrap.innerHTML = '<div class="container"><div class="spinner"></div></div>';
  try {
    const orders = await api('GET', '/orders');
    const steps  = ['Pending','Processing','Shipped','Delivered'];

    wrap.innerHTML = `
    <div class="container orders-wrap">
      <h2 style="font-size:1.4rem;font-weight:800;margin-bottom:22px">📦 My Orders <span style="color:var(--text-muted);font-size:.9rem">(${orders.length})</span></h2>
      ${!orders.length ? '<div style="text-align:center;padding:60px;color:var(--text-muted)">No orders yet. <span style="color:var(--primary);cursor:pointer" onclick="navigate(\'home\')">Start shopping!</span></div>' :
        orders.map(o => {
          const step = statusStep(o.status);
          return `
          <div class="order-card">
            <div class="order-header">
              <div>
                <div class="order-id">#${o.id}</div>
                <div class="order-date">${new Date(o.date).toLocaleDateString('en-IN',{day:'numeric',month:'long',year:'numeric'})}</div>
              </div>
              <div style="display:flex;align-items:center;gap:12px">
                <span class="status-badge status-${o.status.replace(' ','')}">${o.status}</span>
                <span style="font-size:.8rem;color:var(--text-muted)">${o.paymentMethod}</span>
              </div>
            </div>
            ${o.status !== 'Cancelled' ? `
            <div class="order-track">
              ${steps.map((s,i) => `
              <div class="track-step" style="flex:${i<steps.length-1?'1':'0 0 auto'}">
                <div style="display:flex;align-items:center;width:100%">
                  <div class="track-dot ${i<step?'done':i===step?'active':''}">
                    ${i<step?'✓':i===step?'●':''}
                  </div>
                  ${i<steps.length-1?`<div class="track-line ${i<step?'done':''}"></div>`:''}
                </div>
                <div class="track-label">${s}</div>
              </div>`).join('')}
            </div>` : ''}
            <div class="order-items">
              ${o.items.map(item => `
              <div class="order-item">
                <img src="${item.image}" alt="${item.name}" onerror="this.src='https://placehold.co/60x60/1e1e24/ff6b00?text=P'" />
                <div class="order-item-info">
                  <div class="order-item-name">${item.name}</div>
                  <div class="order-item-price">${fmt(item.price)} × ${item.qty}</div>
                </div>
                <div style="font-weight:700;font-size:.95rem">${fmt(item.price*item.qty)}</div>
              </div>`).join('')}
            </div>
            <div class="order-footer">
              <div style="font-size:.83rem;color:var(--text-muted)">📍 ${o.address}</div>
              <div class="order-total">Total: ${fmt(o.total)}</div>
            </div>
          </div>`;
        }).join('')}
    </div>
    <footer>© 2024 ShopNova. All rights reserved.</footer>`;
  } catch(e) { wrap.innerHTML = `<div class="container" style="padding:60px;text-align:center;color:var(--danger)">${e.message}</div>`; }
}

// ─── PROFILE PAGE ─────────────────────────────────────────────────────────────
function renderProfile() {
  const wrap = $('page-profile');
  if (!state.user) { navigate('auth'); return; }
  const u = state.user;
  const initials = u.name.split(' ').map(n=>n[0]).join('').slice(0,2).toUpperCase();

  wrap.innerHTML = `
  <div class="container">
    <div class="profile-layout">
      <div class="profile-sidebar">
        <div class="profile-avatar">${initials}</div>
        <div class="profile-name">${u.name}</div>
        <div class="profile-email">${u.email}</div>
        <div style="background:rgba(255,107,0,.1);border:1px solid rgba(255,107,0,.3);border-radius:8px;padding:6px 14px;font-size:.78rem;color:var(--primary);margin-bottom:20px;display:inline-block">
          ${u.role === 'admin' ? '🔑 Administrator' : '🧑 Customer'}
        </div>
        <div class="profile-nav">
          <div class="profile-nav-item active">👤 Personal Info</div>
          <div class="profile-nav-item" onclick="navigate('orders')">📦 My Orders</div>
          <div class="profile-nav-item" onclick="navigate('cart')">🛒 My Cart</div>
          ${u.role==='admin'?`<div class="profile-nav-item" onclick="navigate('admin')">⚙️ Admin Panel</div>`:''}
          <div class="profile-nav-item" style="color:var(--danger)" onclick="logout()">🚪 Logout</div>
        </div>
      </div>
      <div class="profile-content">
        <div class="profile-section">
          <h3>Personal Information</h3>
          <div class="info-grid">
            <div class="info-item"><label>Full Name</label><span>${u.name}</span></div>
            <div class="info-item"><label>Email</label><span>${u.email}</span></div>
            <div class="info-item"><label>Role</label><span style="text-transform:capitalize">${u.role}</span></div>
            <div class="info-item"><label>Member Since</label><span>2024</span></div>
          </div>
        </div>
        <div class="profile-section">
          <h3>Account Statistics</h3>
          <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:14px">
            ${[['Total Orders','—','📦'],['Cart Items',state.cart.length,'🛒'],['Wishlist','0','❤️']].map(([l,v,i])=>`
            <div style="background:var(--dark3);border-radius:10px;padding:16px;text-align:center">
              <div style="font-size:1.6rem">${i}</div>
              <div style="font-size:1.3rem;font-weight:800;color:var(--primary);margin:6px 0">${v}</div>
              <div style="font-size:.78rem;color:var(--text-muted)">${l}</div>
            </div>`).join('')}
          </div>
        </div>
        <div class="profile-section">
          <h3>Quick Actions</h3>
          <div style="display:flex;gap:10px;flex-wrap:wrap">
            <button class="btn btn-primary" onclick="navigate('orders')">📦 View Orders</button>
            <button class="btn btn-outline" onclick="navigate('cart')">🛒 View Cart</button>
            <button class="btn btn-outline" onclick="navigate('home')">🛍 Shop Now</button>
            <button class="btn btn-outline" style="color:var(--danger);border-color:var(--danger)" onclick="logout()">🚪 Logout</button>
          </div>
        </div>
      </div>
    </div>
  </div>
  <footer>© 2024 ShopNova. All rights reserved.</footer>`;
}

// ─── ADMIN PAGE ───────────────────────────────────────────────────────────────
async function renderAdmin() {
  const wrap = $('page-admin');
  if (!state.user || state.user.role !== 'admin') { toast('Admin access required', 'error'); navigate('home'); return; }

  const navItems = [
    { id:'dashboard', icon:'📊', label:'Dashboard' },
    { id:'products',  icon:'📦', label:'Products' },
    { id:'customers', icon:'👥', label:'Customers' },
    { id:'orders',    icon:'🛍', label:'Orders' },
  ];

  wrap.innerHTML = `
  <div class="admin-layout">
    <div class="admin-sidebar">
      <div class="admin-sidebar-logo">⚡ ShopNova Admin</div>
      ${navItems.map(n=>`
      <div class="admin-nav-item ${state.adminSection===n.id?'active':''}" onclick="adminNav('${n.id}')">
        <span class="nav-icon">${n.icon}</span>${n.label}
      </div>`).join('')}
      <div class="admin-nav-item" style="margin-top:auto;color:var(--danger)" onclick="logout()">
        <span class="nav-icon">🚪</span>Logout
      </div>
    </div>
    <div class="admin-main" id="adminMain">
      <div class="spinner"></div>
    </div>
  </div>`;

  await loadAdminSection();
}

function adminNav(section) {
  state.adminSection = section;
  document.querySelectorAll('.admin-nav-item').forEach((el,i) => el.classList.toggle('active', i < 4 && ['dashboard','products','customers','orders'][i] === section));
  loadAdminSection();
}

async function loadAdminSection() {
  const main = $('adminMain');
  if (!main) return;
  main.innerHTML = '<div class="spinner"></div>';
  try {
    if (state.adminSection === 'dashboard') await renderAdminDashboard(main);
    if (state.adminSection === 'products')  await renderAdminProducts(main);
    if (state.adminSection === 'customers') await renderAdminCustomers(main);
    if (state.adminSection === 'orders')    await renderAdminOrders(main);
  } catch(e) { main.innerHTML = `<p style="color:var(--danger)">${e.message}</p>`; }
}

async function renderAdminDashboard(main) {
  const data = await api('GET', '/admin/dashboard');
  main.innerHTML = `
  <div class="admin-page-title">📊 Dashboard</div>
  <div class="stat-cards">
    ${[
      { icon:'👥', val: data.totalUsers,    label:'Total Customers', change:'+12% this month' },
      { icon:'📦', val: data.totalProducts, label:'Total Products',  change:'+3 added today' },
      { icon:'🛍', val: data.totalOrders,   label:'Total Orders',    change:'+8% this week' },
      { icon:'💰', val: fmt(data.totalRevenue), label:'Total Revenue', change:'+22% vs last month' },
    ].map(s=>`
    <div class="stat-card">
      <div class="stat-icon">${s.icon}</div>
      <div class="stat-val">${s.val}</div>
      <div class="stat-label">${s.label}</div>
      <div class="stat-change">↑ ${s.change}</div>
    </div>`).join('')}
  </div>
  <div class="admin-grid2">
    <div class="admin-table-wrap">
      <div class="admin-table-header"><h3>Recent Orders</h3></div>
      <div style="overflow:auto">
        <table class="data-table">
          <thead><tr><th>Order ID</th><th>Customer</th><th>Amount</th><th>Status</th><th>Payment</th></tr></thead>
          <tbody>
            ${data.recentOrders.map(o=>`
            <tr>
              <td style="color:var(--primary);font-weight:600">#${o.id}</td>
              <td>${o.address?.split(',')[0] || '—'}</td>
              <td style="font-weight:700">${fmt(o.total)}</td>
              <td><span class="status-badge status-${o.status.replace(' ','')}">${o.status}</span></td>
              <td style="font-size:.82rem;color:var(--text-muted)">${o.paymentMethod}</td>
            </tr>`).join('')}
          </tbody>
        </table>
      </div>
    </div>
    <div class="activity-panel">
      <h3>⚡ Activity Log</h3>
      ${data.activityLog.map(a=>`
      <div class="activity-item">
        <div class="act-icon ${a.type}">${{order:'🛍',user:'👤',payment:'💰',product:'📦'}[a.type]||'📋'}</div>
        <div class="act-msg">${a.message}</div>
        <div class="act-time">${a.time}</div>
      </div>`).join('')}
    </div>
  </div>`;
}

async function renderAdminProducts(main) {
  const prods = await api('GET', '/products');
  main.innerHTML = `
  <div class="admin-page-title">📦 Products</div>
  <div class="admin-table-wrap">
    <div class="admin-table-header">
      <h3>All Products (${prods.length})</h3>
      <button class="btn btn-primary btn-sm" onclick="openAddProduct()">+ Add Product</button>
    </div>
    <div style="overflow:auto">
      <table class="data-table">
        <thead><tr><th>Image</th><th>Name</th><th>Category</th><th>Price</th><th>Stock</th><th>Rating</th><th>Actions</th></tr></thead>
        <tbody>
          ${prods.map(p=>`
          <tr>
            <td><img src="${p.image}" style="width:48px;height:48px;object-fit:cover;border-radius:8px" onerror="this.src='https://placehold.co/48x48/1e1e24/ff6b00?text=P'" /></td>
            <td style="font-weight:600;max-width:180px">${p.name}</td>
            <td><span style="background:rgba(255,107,0,.1);color:var(--primary);padding:3px 9px;border-radius:5px;font-size:.75rem">${p.category}</span></td>
            <td style="font-weight:700">${fmt(p.price)}</td>
            <td><span class="${p.stock>20?'in-stock':p.stock>0?'low-stock':'out-stock'}">${p.stock}</span></td>
            <td>${p.rating}★</td>
            <td>
              <button class="btn btn-outline btn-sm" style="margin-right:6px" onclick="openEditProduct('${p.id}')">Edit</button>
              <button class="btn btn-danger btn-sm" onclick="deleteProduct('${p.id}')">Delete</button>
            </td>
          </tr>`).join('')}
        </tbody>
      </table>
    </div>
  </div>`;
}

async function renderAdminCustomers(main) {
  const customers = await api('GET', '/admin/customers');
  main.innerHTML = `
  <div class="admin-page-title">👥 Customers</div>
  <div class="admin-table-wrap">
    <div class="admin-table-header"><h3>All Customers (${customers.length})</h3></div>
    <div style="overflow:auto">
      <table class="data-table">
        <thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Address</th><th>Orders</th><th>Joined</th></tr></thead>
        <tbody>
          ${customers.map(c=>`
          <tr>
            <td>
              <div style="display:flex;align-items:center;gap:10px">
                <div style="width:34px;height:34px;border-radius:50%;background:linear-gradient(135deg,var(--primary),#ff9500);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:.8rem">
                  ${c.name.split(' ').map(n=>n[0]).join('').slice(0,2).toUpperCase()}
                </div>
                <span style="font-weight:600">${c.name}</span>
              </div>
            </td>
            <td style="color:var(--text-muted)">${c.email}</td>
            <td>${c.phone||'—'}</td>
            <td style="font-size:.82rem;max-width:160px;color:var(--text-muted)">${c.address||'—'}</td>
            <td><span style="background:rgba(59,130,246,.15);color:var(--info);padding:3px 10px;border-radius:99px;font-size:.8rem;font-weight:700">${c.orders}</span></td>
            <td style="font-size:.82rem;color:var(--text-muted)">${new Date(c.createdAt).toLocaleDateString('en-IN')}</td>
          </tr>`).join('')}
        </tbody>
      </table>
    </div>
  </div>`;
}

async function renderAdminOrders(main) {
  const orders = await api('GET', '/orders');
  main.innerHTML = `
  <div class="admin-page-title">🛍 All Orders</div>
  <div class="admin-table-wrap">
    <div class="admin-table-header"><h3>All Orders (${orders.length})</h3></div>
    <div style="overflow:auto">
      <table class="data-table">
        <thead><tr><th>Order ID</th><th>Items</th><th>Total</th><th>Payment</th><th>Status</th><th>Date</th><th>Update</th></tr></thead>
        <tbody>
          ${orders.map(o=>`
          <tr>
            <td style="color:var(--primary);font-weight:600">#${o.id}</td>
            <td style="font-size:.82rem;color:var(--text-muted)">${o.items.length} item(s)</td>
            <td style="font-weight:700">${fmt(o.total)}</td>
            <td style="font-size:.82rem">${o.paymentMethod}</td>
            <td><span class="status-badge status-${o.status.replace(' ','')}">${o.status}</span></td>
            <td style="font-size:.78rem;color:var(--text-muted)">${new Date(o.date).toLocaleDateString('en-IN')}</td>
            <td>
              <select class="form-control" style="padding:5px 9px;font-size:.8rem;border-radius:7px" onchange="updateOrderStatus('${o.id}',this.value)">
                ${['Pending','Processing','Shipped','Delivered','Cancelled'].map(s=>`<option ${s===o.status?'selected':''}>${s}</option>`).join('')}
              </select>
            </td>
          </tr>`).join('')}
        </tbody>
      </table>
    </div>
  </div>`;
}

async function updateOrderStatus(orderId, status) {
  try {
    await api('PUT', '/admin/orders/' + orderId + '/status', { status });
    toast(`Order status updated to ${status}`, 'success');
  } catch(e) { toast(e.message, 'error'); }
}

function openAddProduct() {
  openModal(`
  <h3 style="margin-bottom:20px">➕ Add New Product</h3>
  <div class="form-group"><label>Product Name</label><input class="form-control" id="ap_name" placeholder="e.g. Sony WH-1000XM5" /></div>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
    <div class="form-group"><label>Price (₹)</label><input class="form-control" id="ap_price" type="number" placeholder="29999" /></div>
    <div class="form-group"><label>Stock</label><input class="form-control" id="ap_stock" type="number" placeholder="100" /></div>
  </div>
  <div class="form-group"><label>Category</label>
    <select class="form-control" id="ap_cat"><option>Electronics</option><option>Fashion</option><option>Home</option><option>Other</option></select>
  </div>
  <div class="form-group"><label>Description</label><textarea class="form-control" id="ap_desc" rows="3" placeholder="Product description..."></textarea></div>
  <div class="form-group"><label>Image URL</label><input class="form-control" id="ap_img" placeholder="https://...image.jpg" /></div>
  <button class="btn btn-primary btn-full" style="margin-top:8px" onclick="submitAddProduct()">Add Product</button>`);
}

async function submitAddProduct() {
  try {
    await api('POST', '/admin/products', {
      name: $('ap_name').value, price: $('ap_price').value, stock: $('ap_stock').value,
      category: $('ap_cat').value, description: $('ap_desc').value, image: $('ap_img').value,
    });
    closeModal(); toast('Product added successfully! ✅', 'success');
    await loadAdminSection();
  } catch(e) { toast(e.message, 'error'); }
}

async function openEditProduct(id) {
  const p = await api('GET', '/products/' + id);
  openModal(`
  <h3 style="margin-bottom:20px">✏️ Edit Product</h3>
  <div class="form-group"><label>Name</label><input class="form-control" id="ep_name" value="${p.name}" /></div>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
    <div class="form-group"><label>Price (₹)</label><input class="form-control" id="ep_price" type="number" value="${p.price}" /></div>
    <div class="form-group"><label>Stock</label><input class="form-control" id="ep_stock" type="number" value="${p.stock}" /></div>
  </div>
  <div class="form-group"><label>Description</label><textarea class="form-control" id="ep_desc" rows="3">${p.description}</textarea></div>
  <div class="form-group"><label>Image URL</label><input class="form-control" id="ep_img" value="${p.image}" /></div>
  <button class="btn btn-primary btn-full" style="margin-top:8px" onclick="submitEditProduct('${p.id}')">Save Changes</button>`);
}

async function submitEditProduct(id) {
  try {
    await api('PUT', '/admin/products/' + id, {
      name: $('ep_name').value, price: +$('ep_price').value, stock: +$('ep_stock').value,
      description: $('ep_desc').value, image: $('ep_img').value,
    });
    closeModal(); toast('Product updated! ✅', 'success'); await loadAdminSection();
  } catch(e) { toast(e.message, 'error'); }
}

async function deleteProduct(id) {
  if (!confirm('Delete this product?')) return;
  await api('DELETE', '/admin/products/' + id);
  toast('Product deleted', 'success'); await loadAdminSection();
}

// ─── INIT ─────────────────────────────────────────────────────────────────────
(async function init() {
  updateNavUI();
  await loadCart();
  navigate('home');
})();
